import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const { fullName, businessName, whatsappNumber, businessCategory, monthlyBudget, businessGoals } = req.body || {};
  if (!fullName || !whatsappNumber) {
    return res.status(400).json({ error: 'Full name and WhatsApp number are required.' });
  }
  // Visible in Vercel Dashboard -> Project -> Logs
  console.log('New 7-Day Trial Lead Received:', { fullName, businessName, whatsappNumber, businessCategory, monthlyBudget, businessGoals });
  return res.status(200).json({ success: true, message: '7-Day Free Trial Application received successfully!' });
}

import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const { fullName, phoneWhatsapp, brandWebsite, monthlyAdSpend } = req.body || {};
  if (!fullName || !phoneWhatsapp) {
    return res.status(400).json({ error: 'Full name and WhatsApp number are required.' });
  }
  console.log('New Ad Audit Request Received:', { fullName, phoneWhatsapp, brandWebsite, monthlyAdSpend });
  return res.status(200).json({ success: true, message: 'Free Ad Audit Request received successfully!' });
}

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';
import { SHANS_AI_SYSTEM_PROMPT, smartFallback } from '../_lib/shans-ai.js';

const MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, history, image } = req.body || {};

    if ((!message || typeof message !== 'string') && !image) {
      return res.status(400).json({ error: 'Message or image is required' });
    }

    const userPrompt =
      (message || '').trim() ||
      (image ? 'Please perform a full free ad audit on this creative and provide your 1-Week Free Ads Management Action Plan.' : '');

    if (process.env.GEMINI_API_KEY) {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const contents: any[] = [];

        if (Array.isArray(history) && history.length > 0) {
          for (const item of history.slice(-6)) {
            contents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.text }],
            });
          }
        }

        const currentParts: any[] = [];
        if (image) {
          let mimeType = 'image/jpeg';
          let base64Data = typeof image === 'string' ? image : image.data;

          if (typeof base64Data === 'string' && base64Data.startsWith('data:')) {
            const commaIdx = base64Data.indexOf(',');
            const mimeMatch = base64Data.substring(0, commaIdx).match(/data:(.*?);base64/);
            if (mimeMatch) mimeType = mimeMatch[1];
            base64Data = base64Data.substring(commaIdx + 1);
          }

          currentParts.push({
            inlineData: {
              mimeType: typeof image === 'object' && image.mimeType ? image.mimeType : mimeType,
              data: base64Data,
            },
          });
        }
        currentParts.push({ text: userPrompt });
        contents.push({ role: 'user', parts: currentParts });

        const response = await ai.models.generateContent({
          model: MODEL,
          contents,
          config: { systemInstruction: SHANS_AI_SYSTEM_PROMPT },
        });

        const reply =
          response.text ||
          'I have analyzed your ad creative! Would you like to activate our 1-Week Free Ads Management Trial or speak directly with Shan on WhatsApp (+92 333 2327001)?';
        return res.status(200).json({ reply });
      } catch (geminiError) {
        console.warn('Gemini API call error, using fallback knowledge base:', geminiError);
      }
    }

    return res.status(200).json({ reply: smartFallback(userPrompt, !!image) });
  } catch (error) {
    console.error('Error in /api/ai/chat:', error);
    return res.status(500).json({
      error: 'Failed to process AI response',
      reply: "I'm having a brief connection delay. Please feel free to chat directly with Shan on WhatsApp at https://wa.me/923332327001!",
    });
  }
}

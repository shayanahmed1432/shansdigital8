import { ArrowUp, MessageCircle, Mail, Shield, Award, Gift } from 'lucide-react';
import { PageRoute } from '../types';

interface FooterProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function Footer({ onOpenAudit, onNavigate }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const serviceLinks: { id: PageRoute; label: string; badge?: string }[] = [
    { id: 'meta-ads', label: 'Meta Ads Management', badge: 'Flagship' },
    { id: 'social-media', label: 'Social Media Marketing' },
    { id: 'tiktok-ads', label: 'TikTok Ads Management' },
    { id: 'creative-services', label: 'Creative Services & Hooks' },
    { id: 'ecommerce-management', label: 'E-commerce Management' },
  ];

  const exploreLinks: { id: PageRoute; label: string }[] = [
    { id: 'results', label: 'Verified Results Gallery' },
    { id: 'calculator', label: 'Multi-Country ROAS Calculator' },
    { id: 'creative-lab', label: 'Creative Strategy Lab' },
    { id: 'offers', label: '7-Day Free Trial & Offers' },
    { id: 'agency', label: 'About Shan & Philosophy' },
    { id: 'contact', label: 'Contact & Inquiries' },
  ];

  return (
    <footer className="bg-[#080808] text-neutral-400 border-t border-neutral-800/80 pt-16 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-neutral-800">
          {/* Col 1: Brand Wordmark & Tagline */}
          <div className="md:col-span-5 space-y-4">
            <button
              onClick={() => {
                onNavigate('home');
                scrollToTop();
              }}
              className="flex items-center gap-3 text-left focus:outline-none group"
            >
              {/* White Logo on dark footer as specified */}
              <div className="h-12 w-12 flex items-center justify-center transition-transform group-hover:scale-105">
                <img
                  src="/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png"
                  alt="Shan'S Digital8 Mark"
                  className="w-full h-full object-contain filter drop-shadow-md"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black text-white tracking-tight leading-tight">
                  <span className="text-orange-500">Shan'S</span> Digital8
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest text-neutral-400">
                  Innovative Digital Solutions
                </span>
              </div>
            </button>

            <p className="text-xs sm:text-sm text-neutral-400 max-w-sm leading-relaxed">
              Full-service digital marketing & e-commerce growth agency. Scaling local Pakistani businesses (COD & WhatsApp funnels in PKR) and global DTC brands in the USA, UK, and UAE with performance advertising.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="https://wa.me/923332327001?text=Hi!%20I%20want%20to%20know%20more%20about%20your%20digital%20marketing%20services."
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors border border-neutral-800 flex items-center gap-2 text-xs font-semibold"
                aria-label="WhatsApp Shan"
              >
                <MessageCircle className="w-4 h-4 text-emerald-500" />
                <span>WhatsApp Shan</span>
              </a>

              <button
                onClick={() => {
                  onNavigate('offers');
                  scrollToTop();
                }}
                className="px-3.5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors border border-neutral-800 flex items-center gap-2 text-xs font-semibold"
                aria-label="7-Day Trial"
              >
                <Gift className="w-4 h-4 text-orange-500" />
                <span>7-Day Free Trial</span>
              </button>
            </div>
          </div>

          {/* Col 2: Services Links */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-orange-500" />
              <span>Agency Services</span>
            </div>
            <ul className="space-y-2 text-xs sm:text-sm">
              {serviceLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => {
                      onNavigate(link.id);
                      scrollToTop();
                    }}
                    className="hover:text-orange-400 transition-colors text-left flex items-center gap-2"
                  >
                    <span>{link.label}</span>
                    {link.badge && (
                      <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/30">
                        {link.badge}
                      </span>
                    )}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Explore & Audit */}
          <div className="md:col-span-3 space-y-4">
            <div className="text-xs font-bold text-white uppercase tracking-wider">
              Explore & Resources
            </div>
            <ul className="space-y-2 text-xs sm:text-sm">
              {exploreLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => {
                      onNavigate(link.id);
                      scrollToTop();
                    }}
                    className="hover:text-orange-400 transition-colors text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>

            <div className="pt-2">
              <button
                onClick={onOpenAudit}
                className="w-full py-3 px-4 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 rounded-xl shadow-md transition-all active:scale-95"
              >
                GET FREE ADS AUDIT
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Legal & Attribution */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            © {new Date().getFullYear()} Shan'S Digital8. All rights reserved. Innovative Digital Solutions.
          </div>

          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-neutral-400">
              <Shield className="w-3.5 h-3.5 text-orange-500" />
              Meta Certified Media Buyer & CAPI Partner
            </span>
            <button
              onClick={scrollToTop}
              className="hover:text-orange-400 transition-colors flex items-center gap-1"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

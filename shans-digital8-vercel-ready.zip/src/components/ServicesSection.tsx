import { SERVICES } from '../data/portfolioData';
import { ArrowUpRight, Check, Zap, Layers, BarChart3, Video } from 'lucide-react';

interface ServicesSectionProps {
  onOpenAudit: () => void;
}

export default function ServicesSection({ onOpenAudit }: ServicesSectionProps) {
  const getIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <Layers className="w-5 h-5 text-orange-500" />;
      case 1:
        return <Zap className="w-5 h-5 text-amber-500" />;
      case 2:
        return <Video className="w-5 h-5 text-orange-500" />;
      default:
        return <BarChart3 className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <section id="services" className="py-20 md:py-28 bg-neutral-50/60 dark:bg-neutral-900/40 border-t border-neutral-200 dark:border-neutral-800 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl space-y-3 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            Full-Funnel Media Buying Engine
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            Engineering High-Performance Paid Acquisition.
          </h2>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            We don't just "boost posts" or set up generic interest groups. We architect full-funnel acquisition machines
            powered by machine-learning algorithms, custom audience science, and rapid creative iteration.
          </p>
        </div>

        {/* Services Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service, idx) => (
            <div
              key={service.number}
              className="group p-8 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm hover:border-orange-500/50 dark:hover:border-orange-500/50 hover:shadow-xl transition-all duration-300 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                {/* Header: Editorial index + Icon */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-mono font-bold text-orange-600 dark:text-orange-400">
                      {service.number}.
                    </span>
                    <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700">
                      {getIcon(idx)}
                    </div>
                  </div>

                  {/* Platform labels as unboxed text */}
                  <div className="text-xs text-neutral-400 flex items-center gap-1.5 font-medium">
                    {service.platforms.map((p, pIdx) => (
                      <span key={p}>
                        {p}
                        {pIdx < service.platforms.length - 1 && <span className="ml-1 text-neutral-500">·</span>}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-white group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors">
                    {service.title}
                  </h3>
                  <div className="text-xs font-semibold text-orange-600 dark:text-orange-400">
                    {service.tagline}
                  </div>
                </div>

                <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {service.description}
                </p>

                {/* Feature checklist */}
                <div className="space-y-2.5 pt-2">
                  {service.features.map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-2.5 text-xs text-neutral-700 dark:text-neutral-300">
                      <Check className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Card Action */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <span className="text-xs text-neutral-500 font-medium">
                  Custom sprint available
                </span>
                <button
                  onClick={onOpenAudit}
                  className="text-xs font-bold text-neutral-900 dark:text-white hover:text-orange-600 dark:hover:text-orange-400 flex items-center gap-1.5 group-hover:translate-x-0.5 transition-all"
                >
                  <span>Inquire for Your Brand</span>
                  <ArrowUpRight className="w-4 h-4 text-orange-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

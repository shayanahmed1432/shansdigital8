export default function MetricsBar() {
  const metrics = [
    {
      value: '$4.8M+',
      label: 'Ad Spend Managed',
      detail: 'Across Meta (FB/IG) & TikTok Ads',
    },
    {
      value: '5.8x',
      label: 'Average Blended ROAS',
      detail: 'For e-commerce & scaling brands',
    },
    {
      value: '120+',
      label: 'Brands Scaled Globally',
      detail: 'US, UK, UAE, Europe & Pakistan',
    },
    {
      value: '$28M+',
      label: 'Attributed Client Revenue',
      detail: 'Direct-response tracked via CAPI',
    },
  ];

  return (
    <section className="border-y border-neutral-200 dark:border-neutral-800/80 bg-neutral-50/70 dark:bg-neutral-900/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {metrics.map((metric, idx) => (
            <div key={idx} className="flex flex-col space-y-1">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-mono text-neutral-900 dark:text-white tabular-nums tracking-tight">
                {metric.value.startsWith('$') ? (
                  <>
                    <span className="text-orange-500">{metric.value.charAt(0)}</span>
                    {metric.value.slice(1)}
                  </>
                ) : (
                  <>
                    {metric.value.slice(0, -1)}
                    <span className="text-orange-500">{metric.value.slice(-1)}</span>
                  </>
                )}
              </div>
              <div className="text-sm font-semibold text-neutral-900 dark:text-neutral-200 pt-1">
                {metric.label}
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">
                {metric.detail}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

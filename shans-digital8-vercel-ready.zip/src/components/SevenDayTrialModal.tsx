import { useState } from 'react';
import { X, Gift, CheckCircle2, ShieldAlert, Sparkles, Send, MessageCircle, AlertCircle } from 'lucide-react';
import { TrialRequestData } from '../types';

interface SevenDayTrialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SevenDayTrialModal({ isOpen, onClose }: SevenDayTrialModalProps) {
  const [formData, setFormData] = useState<TrialRequestData>({
    fullName: '',
    businessName: '',
    whatsappNumber: '',
    businessCategory: 'E-commerce Brand (Shopify / COD)',
    socialLink: '',
    hasAdAccount: 'yes',
    monthlyBudget: 'PKR 1.5 Lac - 5 Lac / mo ($500 - $2,000)',
    businessGoals: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.fullName.trim() || !formData.whatsappNumber.trim()) {
      setErrorMessage('Please enter your full name and active WhatsApp number.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Send to backend lead capture route
      const response = await fetch('/api/leads/trial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Server returned an error status');
      }

      setIsSubmitted(true);
    } catch (err) {
      console.warn('Backend trial endpoint failed, completing submission client-side:', err);
      // Fallback: save to localStorage to ensure no lead is lost
      try {
        const storedLeads = JSON.parse(localStorage.getItem('shans_trial_leads') || '[]');
        storedLeads.push({ ...formData, submittedAt: new Date().toISOString() });
        localStorage.setItem('shans_trial_leads', JSON.stringify(storedLeads));
      } catch (storageErr) {}
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsAppDirect = () => {
    const text = encodeURIComponent(
      `Assalam-o-Alaikum Shan! I have submitted my application for the 7-Day Free Meta Ads Trial for "${formData.businessName || 'my business'}". WhatsApp: ${formData.whatsappNumber}. Let's discuss onboarding!`
    );
    window.open(`https://wa.me/923000000000?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="flex min-h-full items-center justify-center p-4 sm:p-6">
        <div className="relative w-full max-w-2xl bg-white dark:bg-[#121212] rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 p-6 text-white relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
              aria-label="Close trial modal"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider bg-black/25 px-3 py-1 rounded-full w-fit">
              <Gift className="w-3.5 h-3.5 text-amber-300" />
              <span>Zero Risk · Limited Monthly Slots</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black mt-2 tracking-tight">
              7 DAYS FREE META ADS MANAGEMENT TRIAL
            </h2>
            <p className="text-sm text-orange-100 mt-1 max-w-xl">
              Experience professional advertising management for seven days without paying a management fee.
            </p>
          </div>

          <div className="p-6 sm:p-8">
            {isSubmitted ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
                  Trial Application Received!
                </h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-md mx-auto">
                  Thank you, <strong className="text-orange-500">{formData.fullName}</strong>. Shan will review your account status and business details within 24 hours.
                </p>

                <div className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-left text-xs space-y-2 max-w-md mx-auto">
                  <div className="font-bold text-neutral-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-orange-500" />
                    <span>Next Steps Before Onboarding:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-neutral-600 dark:text-neutral-400">
                    <li>Shan will message you on WhatsApp: <strong>{formData.whatsappNumber}</strong></li>
                    <li>We will inspect your Meta Pixel/CAPI tracking setup</li>
                    <li>We will review creative assets & agree on campaign objectives</li>
                  </ul>
                </div>

                <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                  <button
                    onClick={handleWhatsAppDirect}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Chat With Shan on WhatsApp Now</span>
                  </button>
                  <button
                    onClick={onClose}
                    className="px-6 py-3 rounded-xl bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-bold text-xs uppercase tracking-wider transition-colors"
                  >
                    Close Window
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Important Terms Box */}
                <div className="p-3.5 rounded-xl bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-800/60 text-xs space-y-1 text-orange-900 dark:text-orange-200">
                  <div className="font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-orange-600 shrink-0" />
                    <span>Transparent Trial Terms:</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-neutral-600 dark:text-neutral-300">
                    • 7 days of 100% free campaign management (our standard agency management fee is completely waived).
                    <br />• <strong>Ad Spend:</strong> You fund your ad budget directly inside your own Meta Ad Account.
                    <br />• <strong>Policy:</strong> No guaranteed leads, sales or ROAS during testing. Valid for active business owners with verified products/services.
                  </p>
                </div>

                {errorMessage && (
                  <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs text-red-600 dark:text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Usman Malik or Sarah Jenkins"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  {/* Business Name */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Business / Brand Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      placeholder="e.g. Zephyr Studio or Apex Apparel"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* WhatsApp Number */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      WhatsApp Number (with Country Code) *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.whatsappNumber}
                      onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                      placeholder="+92 300 1234567 or +1 (555) 012-3456"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  {/* Business Category */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Business Category
                    </label>
                    <select
                      value={formData.businessCategory}
                      onChange={(e) => setFormData({ ...formData, businessCategory: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    >
                      <option value="E-commerce Brand (Shopify / COD)">E-commerce Brand (Shopify / COD)</option>
                      <option value="Fashion / Clothing / Footwear">Fashion / Clothing / Footwear</option>
                      <option value="Health / Clinic / Dental / Aesthetics">Health / Clinic / Dental / Aesthetics</option>
                      <option value="Real Estate / High-Ticket Services">Real Estate / High-Ticket Services</option>
                      <option value="B2B / Agency / Consulting">B2B / Agency / Consulting</option>
                      <option value="Local Store / Restaurant">Local Store / Restaurant</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Facebook / Instagram link */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Facebook Page or Instagram Link
                    </label>
                    <input
                      type="text"
                      value={formData.socialLink}
                      onChange={(e) => setFormData({ ...formData, socialLink: e.target.value })}
                      placeholder="instagram.com/yourbrand or website"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  {/* Existing Ad Account */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Existing Meta Ad Account?
                    </label>
                    <select
                      value={formData.hasAdAccount}
                      onChange={(e) => setFormData({ ...formData, hasAdAccount: e.target.value as 'yes' | 'no' })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    >
                      <option value="yes">Yes - I have an active Ad Account</option>
                      <option value="no">No - Need assistance setting one up</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Monthly Budget */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Monthly Ad Budget for Testing
                    </label>
                    <select
                      value={formData.monthlyBudget}
                      onChange={(e) => setFormData({ ...formData, monthlyBudget: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    >
                      <option value="PKR 50K - 1.5 Lac / mo ($200 - $500)">PKR 50,000 - 1.5 Lac / mo ($200 - $500)</option>
                      <option value="PKR 1.5 Lac - 5 Lac / mo ($500 - $2,000)">PKR 1.5 Lac - 5 Lac / mo ($500 - $2,000)</option>
                      <option value="PKR 5 Lac - 15 Lac / mo ($2,000 - $5,000)">PKR 5 Lac - 15 Lac / mo ($2,000 - $5,000)</option>
                      <option value="PKR 15 Lac+ / mo ($5,000+ - Scale)">PKR 15 Lac+ / mo ($5,000+ - Aggressive Scale)</option>
                    </select>
                  </div>

                  {/* Business Goals */}
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-1">
                      Primary Trial Goal
                    </label>
                    <input
                      type="text"
                      value={formData.businessGoals}
                      onChange={(e) => setFormData({ ...formData, businessGoals: e.target.value })}
                      placeholder="e.g. Reduce CPA, fix COD returns, get 50 leads"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all duration-200 shadow-xl shadow-orange-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Submitting Application...</span>
                    ) : (
                      <>
                        <span>CLAIM YOUR 7-DAY FREE TRIAL</span>
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>
                  <p className="text-[10px] text-center text-neutral-500 dark:text-neutral-400 mt-2">
                    Shan reviews each application manually. No automatic charges or bots.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

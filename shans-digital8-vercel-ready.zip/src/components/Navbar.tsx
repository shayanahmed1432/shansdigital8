import { useState, useEffect, useRef } from 'react';
import { Sun, Moon, ArrowUpRight, Menu, X, ChevronDown, Sparkles, MessageCircle, Layers, CheckCircle2 } from 'lucide-react';
import { PageRoute } from '../types';

interface NavbarProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onOpenAudit: () => void;
  isDark: boolean;
  toggleTheme: () => void;
}

export default function Navbar({
  currentPage,
  onNavigate,
  onOpenAudit,
  isDark,
  toggleTheme,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setServicesDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const serviceItems: { id: PageRoute; label: string; desc: string; badge?: string }[] = [
    {
      id: 'meta-ads',
      label: 'Meta Ads Management',
      desc: 'Flagship Facebook & Instagram performance ads for e-com & lead gen',
      badge: 'Flagship',
    },
    {
      id: 'social-media',
      label: 'Social Media Marketing',
      desc: 'Organic page growth, content calendar, graphic posts & viral reels',
    },
    {
      id: 'tiktok-ads',
      label: 'TikTok Ads Management',
      desc: 'Spark Ads, creator whitelisting & rapid scaling funnels',
    },
    {
      id: 'creative-services',
      label: 'Creative Services & Hooks',
      desc: 'High-converting video concepts, ad copy & UGC hook strategy',
    },
    {
      id: 'ecommerce-management',
      label: 'E-commerce Management',
      desc: 'Shopify, TikTok Shop, Daraz, Amazon & store scaling operations',
    },
    {
      id: 'services',
      label: 'All Services Overview',
      desc: 'Technical CAPI architecture, tracking & full media buying stack',
    },
  ];

  const mainLinks: { id: PageRoute; label: string; badge?: string }[] = [
    { id: 'results', label: 'Case Studies' },
    { id: 'calculator', label: 'ROAS Calculator' },
    { id: 'creative-lab', label: 'Creative Strategy' },
    { id: 'offers', label: 'Offers', badge: '7-Day Free' },
    { id: 'agency', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const isAnyServiceActive = [
    'services',
    'meta-ads',
    'social-media',
    'tiktok-ads',
    'creative-services',
    'ecommerce-management',
  ].includes(currentPage);

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 dark:bg-[#080808]/95 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800 shadow-sm'
          : 'bg-white/85 dark:bg-[#080808]/85 backdrop-blur-sm border-b border-neutral-200/70 dark:border-neutral-800/60'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-20">
          {/* Brand Logo Presentation */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 sm:gap-3 shrink-0 group focus:outline-none text-left min-w-0"
            aria-label="Shan'S Digital8 Homepage"
          >
            {/* Header Logo: Black logo in light theme, White logo in dark theme */}
            <div className="relative h-9 w-9 sm:h-12 sm:w-12 flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shrink-0">
              <img
                src={
                  isDark
                    ? '/assets/aistudio/Shans_Digital8_Logo-removebg-preview_51e9a0bb.png'
                    : '/assets/aistudio/final_logo-removebg-preview_083f68f6.png'
                }
                alt="Shan'S Digital8 Logo"
                className="h-full w-full object-contain filter drop-shadow-sm transition-opacity duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex flex-col justify-center min-w-0">
              <span className="text-lg sm:text-2xl font-black tracking-tight leading-tight whitespace-nowrap">
                <span className="text-orange-600">Shan'S</span>{' '}
                <span className="text-neutral-950 dark:text-white">Digital8</span>
              </span>
              <span className="text-[8px] sm:text-[10px] font-bold tracking-widest uppercase text-neutral-500 dark:text-neutral-400 -mt-0.5 whitespace-nowrap">
                Innovative Digital Solutions
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links with Services Dropdown */}
          <nav className="hidden xl:flex items-center gap-6 text-sm font-medium text-neutral-600 dark:text-neutral-300">
            {/* Services Dropdown Trigger */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                className={`flex items-center gap-1.5 py-2 transition-colors ${
                  isAnyServiceActive
                    ? 'text-orange-600 dark:text-orange-400 font-bold'
                    : 'hover:text-orange-500 dark:hover:text-orange-400'
                }`}
              >
                <span>Services</span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-200 ${
                    servicesDropdownOpen ? 'rotate-180 text-orange-500' : ''
                  }`}
                />
                {isAnyServiceActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 rounded-full" />
                )}
              </button>

              {/* Services Dropdown Menu */}
              {servicesDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-80 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 px-3 py-2 border-b border-neutral-100 dark:border-neutral-800/80">
                    Full-Service Capabilities
                  </div>
                  <div className="py-1">
                    {serviceItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setServicesDropdownOpen(false);
                          onNavigate(item.id);
                        }}
                        className={`w-full text-left px-3 py-2.5 rounded-xl transition-all flex flex-col group ${
                          currentPage === item.id
                            ? 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400'
                            : 'hover:bg-neutral-100 dark:hover:bg-neutral-800/60 text-neutral-800 dark:text-neutral-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold group-hover:text-orange-500 transition-colors">
                            {item.label}
                          </span>
                          {item.badge && (
                            <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5 line-clamp-1">
                          {item.desc}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Standard Nav Links */}
            {mainLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => onNavigate(link.id)}
                  className={`relative py-1 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    isActive
                      ? 'text-orange-600 dark:text-orange-400 font-bold'
                      : 'hover:text-orange-500 dark:hover:text-orange-400'
                  }`}
                >
                  <span>{link.label}</span>
                  {link.badge && (
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20">
                      {link.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Zone: Theme Toggle + GET FREE ADS AUDIT CTA */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <button
              onClick={toggleTheme}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 text-neutral-600 dark:text-neutral-300 hover:text-orange-500 dark:hover:text-orange-400 transition-colors rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Prominent Orange CTA - visible on sm and up, avoiding mobile blowout */}
            <button
              onClick={onOpenAudit}
              className="hidden sm:inline-flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 rounded-xl shadow-md shadow-orange-500/20 hover:shadow-orange-500/35 transition-all duration-200 transform hover:-translate-y-0.5 whitespace-nowrap active:scale-95"
            >
              <span>GET FREE ADS AUDIT</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            {/* Mobile menu button for tablet/mobile quick drawer */}
            <div className="xl:hidden flex items-center">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle navigation menu"
                className="p-2 text-neutral-800 dark:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile/Tablet Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-[#0c0c0c] px-6 py-6 space-y-4 shadow-xl">
          <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
            Agency Navigation
          </div>
          <nav className="flex flex-col space-y-1 text-sm font-medium text-neutral-800 dark:text-neutral-200">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('home');
              }}
              className={`text-left py-2 px-3 rounded-lg transition-colors ${
                currentPage === 'home'
                  ? 'bg-orange-50 dark:bg-neutral-800 text-orange-600 font-bold'
                  : 'hover:text-orange-500'
              }`}
            >
              Home
            </button>

            {/* Service sub-links */}
            <div className="pt-2 pb-1 border-y border-neutral-100 dark:border-neutral-800 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-500 px-3">
                Services
              </span>
              {serviceItems.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate(s.id);
                  }}
                  className={`w-full text-left py-1.5 px-3 rounded-lg text-xs transition-colors flex items-center justify-between ${
                    currentPage === s.id
                      ? 'bg-orange-50 dark:bg-neutral-800 text-orange-600 font-bold'
                      : 'hover:text-orange-500'
                  }`}
                >
                  <span>{s.label}</span>
                  {s.badge && (
                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-500 font-bold">
                      {s.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {mainLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate(link.id);
                  }}
                  className={`text-left py-2 px-3 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-orange-50 dark:bg-neutral-800 text-orange-600 font-bold'
                      : 'hover:text-orange-500'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          <div className="pt-2 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAudit();
              }}
              className="w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-white bg-orange-600 hover:bg-orange-500 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <span>GET FREE ADS AUDIT</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            <a
              href="https://wa.me/923332327001?text=Hi!%20I%20want%20to%20know%20more%20about%20your%20digital%20marketing%20services."
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Shan Directly</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

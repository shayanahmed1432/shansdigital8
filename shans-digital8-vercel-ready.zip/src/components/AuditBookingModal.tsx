import { useState, useEffect } from 'react';
import { X, CheckCircle, ArrowRight, ShieldCheck, MessageCircle, Sparkles, Globe2 } from 'lucide-react';
import { AuditRequestData } from '../types';

interface AuditBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledSpend?: number | null;
}

export default function AuditBookingModal({
  isOpen,
  onClose,
  prefilledSpend,
}: AuditBookingModalProps) {
  const [formData, setFormData] = useState<AuditRequestData>({
    fullName: '',
    email: '',
    phoneWhatsapp: '',
    brandWebsite: '',
    marketRegion: 'Pakistan 🇵🇰 (Local E-com / COD)',
    primaryChannel: 'both',
    monthlyAdSpend: 'Rs. 150,000 - Rs. 500,000/mo',
    primaryChallenge: 'Low ROAS & High CPA',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isPakistan = formData.marketRegion?.includes('Pakistan');

  useEffect(() => {
    if (prefilledSpend) {
      if (prefilledSpend > 40000) {
        // High PKR or high USD
        setFormData((prev) => ({
          ...prev,
          monthlyAdSpend: isPakistan ? 'Rs. 500,000 - Rs. 15 Lacs/mo' : '$20,000 - $50,000/mo',
        }));
      } else {
        setFormData((prev) => ({
          ...prev,
          monthlyAdSpend: isPakistan ? 'Rs. 150,000 - Rs. 500,000/mo' : '$5,000 - $20,000/mo',
        }));
      }
    }
  }, [prefilledSpend, isPakistan]);

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Please enter your name';
    if (!formData.email.trim() || !formData.email.includes('@')) {
      newErrors.email = 'Valid business email is required';
    }
    if (!formData.phoneWhatsapp.trim()) {
      newErrors.phoneWhatsapp = 'Phone / WhatsApp is required for fast confirmation';
    }
    if (!formData.brandWebsite.trim()) {
      newErrors.brandWebsite = 'Please provide your store or website link';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
    }
  };

  const whatsappMessage = encodeURIComponent(
    `Assalam-o-Alaikum / Hi Shan!\nI requested an ad audit for ${formData.brandWebsite} on Shan'S Digital8.\n• Name: ${formData.fullName}\n• Market: ${formData.marketRegion}\n• Spend: ${formData.monthlyAdSpend}\n• Channel: ${formData.primaryChannel}\n• Primary Challenge: ${formData.primaryChallenge}`
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50">
          <div>
            <div className="text-xs font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
              Shan'S Digital8 Growth Sprint
            </div>
            <h3 className="text-xl font-extrabold text-neutral-900 dark:text-white">
              Claim Your Free 15-Min Ad Audit
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-lg text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          {submitted ? (
            <div className="text-center py-8 space-y-6">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-500">
                <CheckCircle className="w-10 h-10" />
              </div>
              <div className="space-y-2">
                <h4 className="text-2xl font-bold text-neutral-900 dark:text-white">
                  Audit Request Received!
                </h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-md mx-auto leading-relaxed">
                  Thank you, <strong>{formData.fullName}</strong>. Shan will personally inspect {formData.brandWebsite}'s campaigns and respond via WhatsApp within 4 to 12 hours.
                </p>
              </div>

              {/* Fast Track WhatsApp CTA */}
              <div className="p-4 rounded-xl bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-3">
                <div className="text-xs text-neutral-500">
                  Want an immediate priority response from Shan?
                </div>
                <a
                  href={`https://wa.me/923000000000?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Open WhatsApp Direct Chat With Shan</span>
                </a>
              </div>

              <button
                onClick={onClose}
                className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
              >
                Done / Return to Portfolio
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="text-xs text-neutral-500 dark:text-neutral-400 pb-1">
                No obligations. Shan will review your ad account structure, CAPI tracking, and creative angles to eliminate wasted ad spend.
              </div>

              {/* Target Market / Region */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5">
                  <Globe2 className="w-3.5 h-3.5 text-orange-500" />
                  <span>Your Target Market & Region</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    'Pakistan 🇵🇰 (Local E-com / COD)',
                    'USA 🇺🇸 (Shopify / DTC)',
                    'UK 🇬🇧',
                    'UAE & GCC 🇦🇪',
                    'Europe & Other 🌍',
                  ].map((region) => (
                    <button
                      key={region}
                      type="button"
                      onClick={() => {
                        const newIsPak = region.includes('Pakistan');
                        setFormData({
                          ...formData,
                          marketRegion: region,
                          monthlyAdSpend: newIsPak
                            ? 'Rs. 150,000 - Rs. 500,000/mo'
                            : '$5,000 - $20,000/mo',
                        });
                      }}
                      className={`py-2 px-2.5 text-xs font-medium rounded-lg border text-left transition-colors truncate ${
                        formData.marketRegion === region
                          ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white font-bold'
                          : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
                      }`}
                    >
                      {region}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name & Email Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="audit-fullName" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                    Full Name *
                  </label>
                  <input
                    id="audit-fullName"
                    type="text"
                    required
                    placeholder="e.g. Bilal Ahmed / Alex Morgan"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                  />
                  {errors.fullName && <div className="text-xs text-red-500">{errors.fullName}</div>}
                </div>

                <div className="space-y-1">
                  <label htmlFor="audit-email" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                    Email Address *
                  </label>
                  <input
                    id="audit-email"
                    type="email"
                    required
                    placeholder="name@yourbrand.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                  />
                  {errors.email && <div className="text-xs text-red-500">{errors.email}</div>}
                </div>
              </div>

              {/* Phone/WhatsApp & Brand Website */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="audit-phone" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                    Phone / WhatsApp *
                  </label>
                  <input
                    id="audit-phone"
                    type="tel"
                    required
                    placeholder="e.g. +92 300 1234567 / WhatsApp"
                    value={formData.phoneWhatsapp}
                    onChange={(e) => setFormData({ ...formData, phoneWhatsapp: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                  />
                  {errors.phoneWhatsapp && <div className="text-xs text-red-500">{errors.phoneWhatsapp}</div>}
                </div>

                <div className="space-y-1">
                  <label htmlFor="audit-brandWebsite" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                    Store or Website URL *
                  </label>
                  <input
                    id="audit-brandWebsite"
                    type="text"
                    required
                    placeholder="yourbrand.com or yourbrand.pk"
                    value={formData.brandWebsite}
                    onChange={(e) => setFormData({ ...formData, brandWebsite: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                  />
                  {errors.brandWebsite && <div className="text-xs text-red-500">{errors.brandWebsite}</div>}
                </div>
              </div>

              {/* Platform Choice */}
              <div className="space-y-1.5 pt-1">
                <label className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                  Target Advertising Platform
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'meta', label: 'Meta Ads (FB/IG)' },
                    { id: 'tiktok', label: 'TikTok Ads' },
                    { id: 'both', label: 'Both (Omnichannel)' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, primaryChannel: p.id })}
                      className={`py-2 px-2 text-xs font-semibold rounded-lg border text-center transition-colors ${
                        formData.primaryChannel === p.id
                          ? 'bg-orange-600 text-white border-orange-600'
                          : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Monthly Ad Spend Range (Adaptive by Market) */}
              <div className="space-y-1.5">
                <label htmlFor="audit-adSpend" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                  Current Monthly Ad Spend ({isPakistan ? 'PKR' : 'USD/Intl'})
                </label>
                <select
                  id="audit-adSpend"
                  value={formData.monthlyAdSpend}
                  onChange={(e) => setFormData({ ...formData, monthlyAdSpend: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                >
                  {isPakistan ? (
                    <>
                      <option value="Rs. 50,000 - Rs. 150,000/mo">Rs. 50,000 - Rs. 150,000/mo (Initial Testing)</option>
                      <option value="Rs. 150,000 - Rs. 500,000/mo">Rs. 150,000 - Rs. 500,000/mo (Growing D2C Store)</option>
                      <option value="Rs. 500,000 - Rs. 15 Lacs/mo">Rs. 500,000 - Rs. 15 Lacs/mo (Established Brand Scale)</option>
                      <option value="Rs. 15 Lacs - Rs. 50 Lacs+/mo">Rs. 15 Lacs - Rs. 50 Lacs+/mo (National Market Leader)</option>
                    </>
                  ) : (
                    <>
                      <option value="Under $2,000/mo">Under $2,000/mo (Looking to launch)</option>
                      <option value="$2,000 - $5,000/mo">$2,000 - $5,000/mo (Validation stage)</option>
                      <option value="$5,000 - $20,000/mo">$5,000 - $20,000/mo (Growth scaling)</option>
                      <option value="$20,000 - $50,000/mo">$20,000 - $50,000/mo (High velocity)</option>
                      <option value="$50,000+/mo">$50,000+/mo (Enterprise brand)</option>
                    </>
                  )}
                </select>
              </div>

              {/* Primary Challenge */}
              <div className="space-y-1.5">
                <label htmlFor="audit-challenge" className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                  Biggest Ad Challenge Right Now
                </label>
                <select
                  id="audit-challenge"
                  value={formData.primaryChallenge}
                  onChange={(e) => setFormData({ ...formData, primaryChallenge: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:border-orange-500 dark:focus:border-orange-500 text-neutral-900 dark:text-white"
                >
                  <option value="Low ROAS & High CPA">Low ROAS & High Customer Acquisition Cost</option>
                  <option value="COD Return Rate & Fake Orders (Pakistan)">High COD Return Rate (RTO) & Fake Orders (Pakistan)</option>
                  <option value="Ad Fatigue & Creative Exhaustion">Ad Fatigue & Running Out of Creative Hooks</option>
                  <option value="iOS 14 & Tracking Blind Spots">iOS 14 Tracking / CAPI Inaccuracies</option>
                  <option value="Inability to Scale Past Current Budget">Can't Scale Budget Without Breaking Margin</option>
                  <option value="Starting From Scratch">New Product / Launching Cold Campaigns</option>
                </select>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 px-6 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>Submit & Request 15-Min Strategy Audit</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 pt-2 text-[11px] text-neutral-500 dark:text-neutral-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>100% Confidential. Zero spam. Directly reviewed by Shan.</span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

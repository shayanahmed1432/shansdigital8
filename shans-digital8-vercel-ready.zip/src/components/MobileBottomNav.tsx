import { useState } from 'react';
import { Home, LayoutGrid, TrendingUp, Gift, MessageCircle, X, ChevronRight, Sparkles, ArrowRight } from 'lucide-react';
import { PageRoute } from '../types';

interface MobileBottomNavProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  onOpenAudit: () => void;
}

export default function MobileBottomNav({
  currentPage,
  onNavigate,
  onOpenAudit,
}: MobileBottomNavProps) {
  const [isServicesDrawerOpen, setIsServicesDrawerOpen] = useState(false);

  // Group service routes so the "Services" tab lights up when on any service page
  const isServicesActive = [
    'services',
    'meta-ads',
    'social-media',
    'tiktok-ads',
    'creative-services',
    'ecommerce-management',
  ].includes(currentPage);

  const isOffersActive = currentPage === 'offers';
  const isResultsActive = currentPage === 'results';
  const isContactActive = currentPage === 'contact';
  const isHomeActive = currentPage === 'home';

  const servicesList: {
    id: PageRoute;
    title: string;
    subtitle: string;
    badge?: string;
  }[] = [
    {
      id: 'meta-ads',
      title: 'Meta Ads Management',
      subtitle: 'Flagship high-ROAS Facebook & Instagram campaigns',
      badge: 'Flagship',
    },
    {
      id: 'social-media',
      title: 'Social Media Marketing',
      subtitle: 'Organic page growth, reels, & monthly content calendar',
    },
    {
      id: 'tiktok-ads',
      title: 'TikTok Ads Management',
      subtitle: 'Spark Ads, creator whitelisting, & TikTok Shop scaling',
      badge: 'High Reach',
    },
    {
      id: 'creative-services',
      title: 'Creative Services & Hooks',
      subtitle: 'Ad visuals, video hooks, UGC strategy, & direct-response copy',
    },
    {
      id: 'ecommerce-management',
      title: 'E-commerce Management',
      subtitle: 'Shopify, TikTok Shop, Daraz, & Amazon growth optimization',
    },
    {
      id: 'services',
      title: 'All Services Overview',
      subtitle: 'Explore complete media buying architecture & CAPI tech stack',
    },
  ];

  return (
    <>
      {/* Mobile Services Slide-Up Drawer */}
      {isServicesDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => setIsServicesDrawerOpen(false)}
          />

          {/* Drawer Sheet */}
          <div className="fixed inset-x-0 bottom-0 z-50 bg-[#121212] border-t border-neutral-800 rounded-t-3xl max-h-[85vh] overflow-y-auto p-6 pb-24 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-orange-600/20 border border-orange-500/30 flex items-center justify-center text-orange-500">
                  <LayoutGrid className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white leading-tight">Agency Services</h3>
                  <p className="text-xs text-neutral-400">Select a specialized growth channel</p>
                </div>
              </div>
              <button
                onClick={() => setIsServicesDrawerOpen(false)}
                className="p-2 rounded-full bg-neutral-900 text-neutral-400 hover:text-white"
                aria-label="Close services menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Services List */}
            <div className="mt-4 space-y-2">
              {servicesList.map((service) => {
                const isSelected = currentPage === service.id;
                return (
                  <button
                    key={service.id}
                    onClick={() => {
                      setIsServicesDrawerOpen(false);
                      onNavigate(service.id);
                    }}
                    className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-orange-950/40 border-orange-500/60 text-white'
                        : 'bg-neutral-900/60 border-neutral-800/80 text-neutral-300 hover:bg-neutral-800/80'
                    }`}
                  >
                    <div className="pr-3">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-bold ${isSelected ? 'text-orange-400' : 'text-white'}`}>
                          {service.title}
                        </span>
                        {service.badge && (
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/30">
                            {service.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-neutral-400 mt-0.5 line-clamp-1">{service.subtitle}</p>
                    </div>
                    <ChevronRight className={`w-4 h-4 shrink-0 ${isSelected ? 'text-orange-500' : 'text-neutral-500'}`} />
                  </button>
                );
              })}
            </div>

            {/* Quick Action inside Drawer */}
            <div className="mt-5 pt-4 border-t border-neutral-800">
              <button
                onClick={() => {
                  setIsServicesDrawerOpen(false);
                  onOpenAudit();
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-orange-950/40"
              >
                <span>Get Free Ads Audit</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fixed Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="fixed bottom-0 inset-x-0 w-full max-w-full z-40 lg:hidden bg-[#0c0c0c]/95 dark:bg-[#080808]/95 backdrop-blur-md border-t border-neutral-800/90 shadow-[0_-8px_25px_rgba(0,0,0,0.7)] px-2 pt-2 pb-[max(env(safe-area-inset-bottom),0.5rem)]"
      >
        <div className="flex items-center justify-around max-w-lg mx-auto">
          {/* 1. Home */}
          <button
            onClick={() => onNavigate('home')}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 relative transition-colors duration-200 ${
              isHomeActive ? 'text-orange-500' : 'text-neutral-400 hover:text-neutral-200'
            }`}
            aria-label="Home"
          >
            <div className="relative">
              <Home className={`w-5 h-5 transition-transform duration-200 ${isHomeActive ? 'scale-110 text-orange-500' : ''}`} />
              {isHomeActive && (
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" />
              )}
            </div>
            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isHomeActive ? 'text-orange-500 font-bold' : 'text-neutral-400'}`}>
              Home
            </span>
          </button>

          {/* 2. Services (opens drawer) */}
          <button
            onClick={() => setIsServicesDrawerOpen(true)}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 relative transition-colors duration-200 ${
              isServicesActive ? 'text-orange-500' : 'text-neutral-400 hover:text-neutral-200'
            }`}
            aria-label="Services Menu"
          >
            <div className="relative">
              <LayoutGrid className={`w-5 h-5 transition-transform duration-200 ${isServicesActive ? 'scale-110 text-orange-500' : ''}`} />
              {isServicesActive && (
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" />
              )}
            </div>
            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isServicesActive ? 'text-orange-500 font-bold' : 'text-neutral-400'}`}>
              Services
            </span>
          </button>

          {/* 3. Results */}
          <button
            onClick={() => onNavigate('results')}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 relative transition-colors duration-200 ${
              isResultsActive ? 'text-orange-500' : 'text-neutral-400 hover:text-neutral-200'
            }`}
            aria-label="Results and Case Studies"
          >
            <div className="relative">
              <TrendingUp className={`w-5 h-5 transition-transform duration-200 ${isResultsActive ? 'scale-110 text-orange-500' : ''}`} />
              {isResultsActive && (
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" />
              )}
            </div>
            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isResultsActive ? 'text-orange-500 font-bold' : 'text-neutral-400'}`}>
              Results
            </span>
          </button>

          {/* 4. Offers (7-day trial + free audit) */}
          <button
            onClick={() => onNavigate('offers')}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 relative transition-colors duration-200 ${
              isOffersActive ? 'text-orange-500' : 'text-neutral-400 hover:text-neutral-200'
            }`}
            aria-label="Free Offers"
          >
            <div className="relative">
              <Gift className={`w-5 h-5 transition-transform duration-200 ${isOffersActive ? 'scale-110 text-orange-500' : ''}`} />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
              {isOffersActive && (
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" />
              )}
            </div>
            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isOffersActive ? 'text-orange-500 font-bold' : 'text-neutral-400'}`}>
              Offers
            </span>
          </button>

          {/* 5. Contact */}
          <button
            onClick={() => onNavigate('contact')}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 relative transition-colors duration-200 ${
              isContactActive ? 'text-orange-500' : 'text-neutral-400 hover:text-neutral-200'
            }`}
            aria-label="Contact and Inquiries"
          >
            <div className="relative">
              <MessageCircle className={`w-5 h-5 transition-transform duration-200 ${isContactActive ? 'scale-110 text-orange-500' : ''}`} />
              {isContactActive && (
                <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-orange-500 shadow-sm shadow-orange-500" />
              )}
            </div>
            <span className={`text-[10px] mt-1 font-medium tracking-tight ${isContactActive ? 'text-orange-500 font-bold' : 'text-neutral-400'}`}>
              Contact
            </span>
          </button>
        </div>
      </nav>
    </>
  );
}

import { useState } from 'react';
import { Eye, Flame, ShieldAlert, Award, MousePointerClick, Smartphone, Layers, CheckCircle2 } from 'lucide-react';

export default function CreativeAnatomy() {
  const [activeFormat, setActiveFormat] = useState<'video' | 'static' | 'instant_form'>('video');

  const videoSteps = [
    {
      time: '00:00 - 00:03',
      name: 'The Scroll-Stopping Hook',
      role: 'Pattern Interrupt',
      goal: 'Achieve >35% 3-second hook rate on Reels and TikTok FYP.',
      tactic:
        'Visually jarring visual motion, controversial question, or direct negative claim ("Stop buying cheap wireless earbuds before you see this").',
      icon: <Eye className="w-5 h-5 text-orange-500" />,
    },
    {
      time: '00:03 - 00:08',
      name: 'Agitation & Relatability',
      role: 'Emotional Resonance',
      goal: 'Hook retention >50% at the 6-second mark.',
      tactic:
        'Calling out the exact daily frustration the customer feels. Show the unpleasant before-state in real lighting without commercial gloss.',
      icon: <Flame className="w-5 h-5 text-amber-500" />,
    },
    {
      time: '00:08 - 00:16',
      name: 'The Unique Mechanism',
      role: 'Product Differentiation',
      goal: 'Justify the price point and eliminate skepticism.',
      tactic:
        'Show how the product solves the problem uniquely. Close-up macro shots, satisfying demonstration, or side-by-side comparison.',
      icon: <Layers className="w-5 h-5 text-orange-500" />,
    },
    {
      time: '00:16 - 00:24',
      name: 'Social Proof & Objections',
      role: 'Risk Reversal',
      goal: 'Remove remaining buying hesitation.',
      tactic:
        'Unfiltered customer testimonials, 5-star review overlays, press citations, and money-back guarantee trust seals.',
      icon: <Award className="w-5 h-5 text-amber-500" />,
    },
    {
      time: '00:24 - 00:30',
      name: 'Frictionless Offer & CTA',
      role: 'Immediate Conversion',
      goal: 'Drive high-intent outbound CTR >3.0%.',
      tactic:
        'Exclusive limited-time promo code, bundle deal ("Buy 1 Get 1 50% Off"), and direct verbal prompt ("Tap below to shop now").',
      icon: <MousePointerClick className="w-5 h-5 text-orange-500" />,
    },
  ];

  return (
    <section id="creative-lab" className="py-20 md:py-28 bg-neutral-50/60 dark:bg-neutral-900/40 border-t border-neutral-200 dark:border-neutral-800 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-3 max-w-2xl">
            <div className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Creative Engineering Blueprint
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
              The Anatomy of a 6.4x ROAS Ad Creative.
            </h2>
            <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
              Modern ad algorithms reward attention retention. Here is the exact psychological sequencing
              we use to engineer ad creative that stops mindless scrolling and drives direct-response action.
            </p>
          </div>

          {/* Format Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800 shrink-0 overflow-x-auto max-w-full no-scrollbar">
            <button
              onClick={() => setActiveFormat('video')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeFormat === 'video'
                  ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Short-Form Video (Reels & TikTok)
            </button>
            <button
              onClick={() => setActiveFormat('static')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeFormat === 'static'
                  ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              Static Advantage+ Carousels
            </button>
            <button
              onClick={() => setActiveFormat('instant_form')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeFormat === 'instant_form'
                  ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-sm'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              High-Ticket Lead Forms
            </button>
          </div>
        </div>

        {/* Content for Short-Form Video */}
        {activeFormat === 'video' && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {videoSteps.map((step, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-4 hover:border-orange-500/50 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">
                      {step.time}
                    </span>
                    <div className="p-1.5 rounded-md bg-neutral-100 dark:bg-neutral-800">
                      {step.icon}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                      {step.name}
                    </h3>
                    <div className="text-xs text-neutral-500 font-medium">
                      {step.role}
                    </div>
                  </div>

                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                    {step.tactic}
                  </p>
                </div>

                <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-500 dark:text-neutral-400 font-mono">
                  Benchmark: <span className="text-neutral-900 dark:text-white font-bold">{step.goal}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Content for Static Carousels */}
        {activeFormat === 'static' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Card 01</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                The Bold Hero Benefit Visual
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Clean studio product shot on warm travertine or dynamic contrast background with an oversized headline highlighting the #1 transformation.
              </p>
              <div className="text-xs text-neutral-500 font-mono">Avg Swipe-Through: 42%</div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Cards 02 - 04</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                Feature Comparison & Proof
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Us vs. Them side-by-side checklist, customer before & after, or real unboxing review quote. Demolishes price resistance in 3 swipes.
              </p>
              <div className="text-xs text-neutral-500 font-mono">CPA Reduction: -28%</div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Final Card</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                The Direct Offer & Bundle Anchor
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Dynamic catalog product card highlighting free shipping, bundle discounts, and instant "Shop Now" deep-link into mobile checkout.
              </p>
              <div className="text-xs text-neutral-500 font-mono">Conversion Rate: 4.6%</div>
            </div>
          </div>
        )}

        {/* Content for Instant Forms */}
        {activeFormat === 'instant_form' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Step 01</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                Intent-Building Intro Screen
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Replaces lazy 1-click forms with a branded value summary detailing what the prospect will receive on their strategy call.
              </p>
              <div className="text-xs text-neutral-500 font-mono">Filters unqualified clicks</div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Step 02</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                Friction Qualification Filter
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Requires applicant to select monthly revenue bracket, company size, and urgency timeline. Discards low-budget leads automatically.
              </p>
              <div className="text-xs text-neutral-500 font-mono">Lead Show-Up Rate: 78%</div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
              <div className="text-xs font-mono font-bold text-orange-600 dark:text-orange-400">Step 03</div>
              <h3 className="text-lg font-bold text-neutral-900 dark:text-white">
                Instant Calendar Booking Sync
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                The completion page redirects directly into a Calendly embed with automated SMS verification to secure the meeting slot within 60 seconds.
              </p>
              <div className="text-xs text-neutral-500 font-mono">Booking Conversion: 44.3%</div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

export interface MarketConfig {
  id: string;
  name: string;
  shortName: string;
  flag: string;
  currencyCode: string;
  currencySymbol: string;
  minSpend: number;
  maxSpend: number;
  stepSpend: number;
  defaultSpend: number;
  defaultRoas: number;
  defaultAov: number;
  aovOptions: number[];
  spendLabels: {
    low: string;
    mid: string;
    high: string;
  };
  presets: {
    label: string;
    spend: number;
    roas: number;
    aov: number;
  }[];
  getRecommendation: (spend: number) => {
    strategy: string;
    focus: string;
    creativeVelocity: string;
    marketInsight: string;
  };
}

export const SUPPORTED_MARKETS: MarketConfig[] = [
  {
    id: 'pk',
    name: 'Pakistan (Local E-com / COD)',
    shortName: 'Pakistan',
    flag: '🇵🇰',
    currencyCode: 'PKR',
    currencySymbol: 'Rs.',
    minSpend: 50000,
    maxSpend: 5000000,
    stepSpend: 25000,
    defaultSpend: 350000,
    defaultRoas: 5.4,
    defaultAov: 4500,
    aovOptions: [2500, 4500, 8500, 15000],
    spendLabels: {
      low: 'Rs. 50K/mo',
      mid: 'Rs. 25 Lac/mo',
      high: 'Rs. 50 Lac+/mo',
    },
    presets: [
      {
        label: 'Lahore/Karachi D2C Starter (Rs. 1 Lac @ 4.8x)',
        spend: 100000,
        roas: 4.8,
        aov: 3200,
      },
      {
        label: 'National PK Brand Scale (Rs. 5 Lac @ 5.8x)',
        spend: 500000,
        roas: 5.8,
        aov: 4500,
      },
      {
        label: 'Top Tier D2C Market Leader (Rs. 25 Lac @ 6.5x)',
        spend: 2500000,
        roas: 6.5,
        aov: 6800,
      },
    ],
    getRecommendation: (spend: number) => {
      if (spend < 200000) {
        return {
          strategy: 'Creative Hook Validation & WhatsApp COD Confirmation',
          focus:
            'Validate top 3 Urdu/Roman Urdu UGC hooks, deploy automated WhatsApp 1-click order confirmation to eliminate fake orders, and establish a verified 85%+ delivery rate baseline.',
          creativeVelocity: '4 to 6 localized video ads / month',
          marketInsight:
            'Cash on Delivery (COD) represents 85%+ of Pakistani e-com. Instant WhatsApp confirmation before courier booking eliminates fake addresses.',
        };
      }
      if (spend <= 1000000) {
        return {
          strategy: 'Meta Advantage+ Shopping & Courier NDR Webhook Automation',
          focus:
            'Deploy unified broad ASC+ campaigns targeting high-purchasing cities (Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan). Integrate PostEx/Trax/Leopards API for re-dispatch triggers on failed deliveries.',
          creativeVelocity: '8 to 12 localized creatives / month',
          marketInsight:
            'Connecting courier Non-Delivery Reports (NDR) back to CRM pushes successful deliveries from 68% to 88%+, preserving brand profit.',
        };
      }
      return {
        strategy: 'High-Volume Multi-City Omnichannel Domination',
        focus:
          'Automated CBO budget scaling with strict minimum ROAS rules, high-velocity dynamic creative testing (DCT), automated VIP customer broadcast funnels, and custom offline courier settlement data syncing.',
        creativeVelocity: '16+ fresh video & carousel assets / month',
        marketInsight:
          "Shan'S Digital8 algorithmic media buying allows top Pakistani apparel, footwear, and cosmetics brands to scale past Rs. 1 Crore+ monthly revenue.",
      };
    },
  },
  {
    id: 'us',
    name: 'United States (USD)',
    shortName: 'USA',
    flag: '🇺🇸',
    currencyCode: 'USD',
    currencySymbol: '$',
    minSpend: 1000,
    maxSpend: 50000,
    stepSpend: 500,
    defaultSpend: 10000,
    defaultRoas: 5.5,
    defaultAov: 75,
    aovOptions: [35, 65, 120, 250],
    spendLabels: {
      low: '$1,000/mo',
      mid: '$25,000/mo',
      high: '$50,000+/mo',
    },
    presets: [
      {
        label: 'Shopify Starter ($3k @ 4.5x)',
        spend: 3000,
        roas: 4.5,
        aov: 55,
      },
      {
        label: 'Growth DTC Scale ($15k @ 6.2x)',
        spend: 15000,
        roas: 6.2,
        aov: 85,
      },
      {
        label: 'Enterprise ASC+ Blitz ($40k @ 7.0x)',
        spend: 40000,
        roas: 7.0,
        aov: 120,
      },
    ],
    getRecommendation: (spend: number) => {
      if (spend < 5000) {
        return {
          strategy: 'Creative Validation & Single-Campaign ASC+ Sprint',
          focus:
            'Validate top 3 UGC hooks, configure Meta CAPI for 95%+ match rate, establish sub-$20 CPA baseline.',
          creativeVelocity: '4 to 6 fresh creatives / month',
          marketInsight:
            'US consumer markets demand strong 3-second hook velocity and authentic organic-style creator footage.',
        };
      }
      if (spend <= 25000) {
        return {
          strategy: 'Meta Advantage+ Shopping & TikTok Spark Ads Hybrid',
          focus:
            'Deploy automated CBO scaling with +20% budget jumps every 48h on winners, expand lookalike seed audiences, and launch TikTok creator Spark Ads.',
          creativeVelocity: '8 to 12 fresh creatives / month',
          marketInsight:
            'Omnichannel synergy between TikTok UGC discovery and Meta retargeting lowers blended CAC by up to 34%.',
        };
      }
      return {
        strategy: 'High-Velocity Omnichannel Scaling & Bid Cap Guardrails',
        focus:
          'Multi-account risk mitigation, Cost Caps / Minimum ROAS bid controls to protect margin at scale, custom offline conversion uploads, and full-funnel retention.',
        creativeVelocity: '16+ fresh creatives / month',
        marketInsight:
          'Utilizing Cost Caps protects profitability during volatile Q4 auction surges.',
      };
    },
  },
  {
    id: 'uk',
    name: 'United Kingdom (GBP)',
    shortName: 'UK',
    flag: '🇬🇧',
    currencyCode: 'GBP',
    currencySymbol: '£',
    minSpend: 800,
    maxSpend: 40000,
    stepSpend: 400,
    defaultSpend: 8000,
    defaultRoas: 5.2,
    defaultAov: 55,
    aovOptions: [25, 55, 95, 180],
    spendLabels: {
      low: '£800/mo',
      mid: '£20,000/mo',
      high: '£40,000+/mo',
    },
    presets: [
      {
        label: 'UK Boutique (£2.5k @ 4.6x)',
        spend: 2500,
        roas: 4.6,
        aov: 45,
      },
      {
        label: 'National Scale (£10k @ 5.8x)',
        spend: 10000,
        roas: 5.8,
        aov: 65,
      },
      {
        label: 'High-Growth DTC (£30k @ 6.8x)',
        spend: 30000,
        roas: 6.8,
        aov: 95,
      },
    ],
    getRecommendation: (spend: number) => {
      if (spend < 4000) {
        return {
          strategy: 'UK Niche Testing & Advantage+ Catalog Sprint',
          focus:
            'Rapid hook validation with UK English voiceover, CAPI integration with Shopify, and dynamic collection ads.',
          creativeVelocity: '4 to 6 localized creatives / month',
          marketInsight:
            'UK audiences respond strongly to transparent customer reviews and localized British social proof.',
        };
      }
      if (spend <= 20000) {
        return {
          strategy: 'Advantage+ Shopping & TikTok Creator Whitelisting',
          focus:
            'Whitelisted UK creator ads with Spark Ads, automated CBO budget increases, and post-purchase bundle upsells.',
          creativeVelocity: '8 to 12 creatives / month',
          marketInsight:
            'Scaling across England, Scotland, and Wales with dynamic delivery time callouts lifts conversion rates.',
        };
      }
      return {
        strategy: 'UK Enterprise Scaling with Bid Protections',
        focus:
          'Algorithmic bid pacing, minimum ROAS guardrails, multi-creative batch testing, and retention email sync.',
        creativeVelocity: '16+ creatives / month',
        marketInsight:
          'High creative velocity beats ad fatigue in the concentrated UK consumer market.',
      };
    },
  },
  {
    id: 'ae',
    name: 'UAE & GCC (AED)',
    shortName: 'UAE / Gulf',
    flag: '🇦🇪',
    currencyCode: 'AED',
    currencySymbol: 'AED ',
    minSpend: 3500,
    maxSpend: 180000,
    stepSpend: 1500,
    defaultSpend: 30000,
    defaultRoas: 5.6,
    defaultAov: 220,
    aovOptions: [120, 220, 450, 950],
    spendLabels: {
      low: 'AED 3.5k/mo',
      mid: 'AED 90k/mo',
      high: 'AED 180k+/mo',
    },
    presets: [
      {
        label: 'Dubai Boutique (AED 10k @ 4.6x)',
        spend: 10000,
        roas: 4.6,
        aov: 180,
      },
      {
        label: 'GCC Scale-Up (AED 45k @ 5.8x)',
        spend: 45000,
        roas: 5.8,
        aov: 280,
      },
      {
        label: 'Luxury & B2B Blitz (AED 120k @ 6.8x)',
        spend: 120000,
        roas: 6.8,
        aov: 520,
      },
    ],
    getRecommendation: (spend: number) => {
      if (spend < 15000) {
        return {
          strategy: 'Bilingual Arabic/English Hook Sprint & High-AOV Bundles',
          focus:
            'Dual-language creative testing, WhatsApp concierge checkout integration, and fast delivery guarantees across Dubai and Abu Dhabi.',
          creativeVelocity: '4 to 6 bilingual creatives / month',
          marketInsight:
            'UAE consumers boast high purchasing power with Average Order Values exceeding AED 200+.',
        };
      }
      if (spend <= 75000) {
        return {
          strategy: 'GCC Multi-Country Expansion (UAE, KSA, Qatar)',
          focus:
            'Expand winning creative angles into Saudi Arabia (KSA) and Kuwait with localized payment badges (Mada, Apple Pay, Tabby/Tamara BNPL).',
          creativeVelocity: '8 to 14 high-end video assets / month',
          marketInsight:
            'Integrating Tabby/Tamara Buy-Now-Pay-Later in ads increases conversion rates by up to 28% across the Gulf.',
        };
      }
      return {
        strategy: 'High-Ticket Luxury Omnichannel Scaling',
        focus:
          'VIP private client lead gen, premium influencer whitelisting, Meta CAPI offline store visit optimization, and high-frequency retargeting.',
        creativeVelocity: '16+ premium video & motion assets / month',
        marketInsight:
          'Luxury brands scale profitably in the GCC through high-trust lifestyle creative storytelling.',
      };
    },
  },
  {
    id: 'eu',
    name: 'Europe & International (EUR)',
    shortName: 'Europe',
    flag: '🇪🇺',
    currencyCode: 'EUR',
    currencySymbol: '€',
    minSpend: 1000,
    maxSpend: 50000,
    stepSpend: 500,
    defaultSpend: 9000,
    defaultRoas: 5.3,
    defaultAov: 65,
    aovOptions: [30, 65, 110, 220],
    spendLabels: {
      low: '€1,000/mo',
      mid: '€25,000/mo',
      high: '€50,000+/mo',
    },
    presets: [
      {
        label: 'EU Brand Starter (€3k @ 4.5x)',
        spend: 3000,
        roas: 4.5,
        aov: 50,
      },
      {
        label: 'Pan-Euro Scale (€15k @ 6.0x)',
        spend: 15000,
        roas: 6.0,
        aov: 80,
      },
      {
        label: 'Global Blitz (€35k @ 6.8x)',
        spend: 35000,
        roas: 6.8,
        aov: 115,
      },
    ],
    getRecommendation: (spend: number) => {
      return {
        strategy: 'Pan-European Algorithmic Scale & Multi-Language Assets',
        focus:
          'Multi-country Advantage+ campaigns across Germany, Netherlands, France and Scandinavia with localized subtitles and Klarna payment badges.',
        creativeVelocity: '8 to 14 creatives / month',
        marketInsight:
          'Multi-country ASC+ testing allows Meta algorithm to find the lowest CPA across EU member states.',
      };
    },
  },
];

export function formatCurrencyAmount(amount: number, market: MarketConfig): string {
  if (market.currencyCode === 'PKR') {
    return `Rs. ${amount.toLocaleString('en-PK')}`;
  }
  return `${market.currencySymbol}${amount.toLocaleString()}`;
}

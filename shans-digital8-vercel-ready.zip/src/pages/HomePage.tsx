import { useState } from 'react';
import Hero from '../components/Hero';
import MetricsBar from '../components/MetricsBar';
import ResultsGallery from '../components/ResultsGallery';
import ProcessSection from '../components/ProcessSection';
import Testimonials from '../components/Testimonials';
import { CaseStudy, PageRoute } from '../types';
import { CASE_STUDIES } from '../data/portfolioData';
import {
  ArrowRight,
  TrendingUp,
  Sparkles,
  MessageCircle,
  Gift,
  Award,
  Layers,
  CheckCircle2,
  Share2,
  ShoppingBag,
  Palette,
  ShieldCheck,
  Building2,
  Stethoscope,
  Shirt,
  Briefcase,
  Store,
  Globe2,
  ChevronDown,
  HelpCircle,
  Send,
  FileSearch,
  Zap,
  Cpu
} from 'lucide-react';

interface HomePageProps {
  onOpenAudit: () => void;
  onOpenTrial: () => void;
  onSelectCaseStudy: (study: CaseStudy) => void;
  onOpenAuditWithSpend: (spend: number) => void;
  onNavigate: (page: PageRoute) => void;
  isDark: boolean;
}

export default function HomePage({
  onOpenAudit,
  onOpenTrial,
  onSelectCaseStudy,
  onOpenAuditWithSpend,
  onNavigate,
  isDark,
}: HomePageProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const mainServices = [
    {
      id: 'meta-ads' as PageRoute,
      title: 'Meta Ads Management',
      flagship: true,
      tagline: 'Flagship Core Service',
      desc: 'Precision Facebook & Instagram advertising engineered for high ROAS and scalable purchases. We manage audience testing, dynamic creative testing (DCT), and server-side CAPI.',
      highlights: ['Advantage+ Shopping & CBO', 'Urdu / English UGC Hook Scripting', 'Server-Side Conversions API (CAPI)'],
      icon: <Award className="w-6 h-6 text-orange-500" />,
    },
    {
      id: 'social-media' as PageRoute,
      title: 'Social Media Marketing',
      flagship: false,
      tagline: 'Organic Brand Building',
      desc: 'Organic Facebook and Instagram profile management. Strategic content calendar, carousel posts, community engagement, and viral reels that build buyer trust.',
      highlights: ['Monthly Content Calendar', 'Curated Aesthetic & Highlights', 'Community & DM Moderation'],
      icon: <Share2 className="w-6 h-6 text-pink-500" />,
    },
    {
      id: 'tiktok-ads' as PageRoute,
      title: 'TikTok Ads Management',
      flagship: false,
      tagline: 'Viral Short-Form Scale',
      desc: 'Explosive top-of-funnel reach with TikTok Spark Ads, creator whitelisting, and TikTok Shop advertising for rapid impulse purchasing.',
      highlights: ['Spark Ads & Creator Whitelisting', '3-Second Retention Hook Strategy', 'TikTok Pixel 2.0 Attribution'],
      icon: <Zap className="w-6 h-6 text-amber-500" />,
    },
    {
      id: 'creative-services' as PageRoute,
      title: 'Creative Services & Hooks',
      flagship: false,
      tagline: 'Direct-Response Assets',
      desc: 'High-converting video concepts, graphic design, and persuasive ad copywriting. We build ads that stop the thumb scroll and trigger buying decisions.',
      highlights: ['High-Converting Visual Angles', 'PAS & AIDA Copywriting', 'Weekly Creative Refresh Cycle'],
      icon: <Palette className="w-6 h-6 text-blue-500" />,
    },
    {
      id: 'ecommerce-management' as PageRoute,
      title: 'E-commerce Management',
      flagship: false,
      tagline: 'Store Growth & Operations',
      desc: 'Full-spectrum operational management across Shopify, TikTok Shop, Daraz, Amazon, and Etsy. Focused 100% on marketing, AOV, and courier delivery optimization.',
      highlights: ['COD Delivery Rate Optimization (88%+)', 'Product Listing SEO & AOV Bundles', 'No generic web development'],
      icon: <ShoppingBag className="w-6 h-6 text-emerald-500" />,
    },
  ];

  const whyChooseUs = [
    {
      title: 'Math-Driven & Profitable Returns',
      desc: 'We optimize for net cash profit, contribution margin, and confirmed deliveries — not superficial vanity metrics or clicks.',
    },
    {
      title: 'Local Pakistani + Global Mastery',
      desc: 'Deep local roots solving Pakistan COD returns and WhatsApp verification, combined with international scaling across USA, UK, and UAE.',
    },
    {
      title: 'Senior Execution, Zero Junior Delegation',
      desc: 'Your campaigns are managed and monitored directly by Shan and seasoned media buyers with over $4.8M+ in managed ad spend.',
    },
    {
      title: 'Modern Technical Infrastructure',
      desc: 'Full Server-Side Meta Conversions API (CAPI), TikTok Advanced Matching, and Cost Cap algorithmic bid protections.',
    },
  ];

  const industries = [
    { name: 'Fashion & Apparel', icon: <Shirt className="w-5 h-5 text-orange-500" />, desc: 'Clothing, footwear, pret wear, luxury fabrics & accessories' },
    { name: 'E-Commerce Brands (D2C)', icon: <Store className="w-5 h-5 text-amber-500" />, desc: 'Shopify brands, TikTok Shop stores, gadgets & lifestyle products' },
    { name: 'Healthcare & Aesthetic Clinics', icon: <Stethoscope className="w-5 h-5 text-emerald-500" />, desc: 'Dental practices, laser clinics, dermatologists & wellness centers' },
    { name: 'Real Estate & Developers', icon: <Building2 className="w-5 h-5 text-blue-500" />, desc: 'High-ticket residential and commercial investment lead generation' },
    { name: 'B2B & Professional Agencies', icon: <Briefcase className="w-5 h-5 text-purple-500" />, desc: 'Corporate consulting, software, logistics & executive services' },
    { name: 'Local Retail & Services', icon: <Globe2 className="w-5 h-5 text-pink-500" />, desc: 'City-wide radius campaigns across Pakistan, US, UK, and GCC' },
  ];

  const faqs = [
    {
      q: 'How does the 7-Day Free Meta Ads Management Trial work?',
      a: 'During the 7-day trial, Shan\'S Digital8 waives our entire agency management fee. You only fund your advertising budget directly inside your own Meta Ad Account. We set up, manage, and monitor your campaigns so you can witness our communication, tactical agility, and performance firsthand with zero long-term commitment.',
    },
    {
      q: 'Do you work with Pakistani businesses operating on Cash-on-Delivery (COD)?',
      a: 'Yes, extensively! We have scaled Pakistani Shopify brands (like Zephyr Studio) past Rs. 85+ Lacs/month. We solve the biggest bottleneck in Pakistan: return-to-origin (RTO) courier loss. We deploy automated WhatsApp order confirmation bots and courier webhooks (PostEx, Trax, Leopards) pushing delivered orders from 60% up to 88%–90%.',
    },
    {
      q: 'Do you manage campaigns for international clients in the US, UK, and UAE?',
      a: 'Yes. We manage international client ad accounts in USD, GBP, and AED. We leverage Advantage+ Shopping Campaigns (ASC+), creator Spark Ads, and strict Cost Cap bidding to scale profitably across competitive Western and Gulf markets.',
    },
    {
      q: 'Why is Meta Ads considered your flagship service?',
      a: 'Meta (Facebook & Instagram) represents the deepest consumer purchase intent and algorithmic targeting engine in digital marketing. With proper Conversions API (CAPI) and high-retention video hooks, Meta Ads generates the highest scalable ROAS across both e-commerce and lead generation.',
    },
    {
      q: 'What is included in the 100% Free Meta Ads Account Audit?',
      a: 'Shan personally reviews your account structure, tracking fidelity (Event Match Quality), audience overlap, high-CPA ad fatigue, and offer economics. You receive a candid breakdown with actionable recommendations within 24 hours at zero charge.',
    },
  ];

  return (
    <div className="space-y-0">
      {/* 1. Hero Section */}
      <Hero
        onOpenAudit={onOpenAudit}
        onExploreServices={() => onNavigate('services')}
        isDark={isDark}
      />

      {/* Metrics Ribbon */}
      <MetricsBar />

      {/* 2. Agency Introduction Section */}
      <section className="py-20 bg-neutral-50 dark:bg-[#0d0d0d] border-y border-neutral-200 dark:border-neutral-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-600 dark:text-orange-400 text-xs font-bold uppercase tracking-wider">
                <span>About Shan'S Digital8</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white tracking-tight [text-wrap:balance]">
                Full-Service Digital Marketing & E-Commerce Growth Agency.
              </h2>
              <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-300 leading-relaxed">
                Founded by performance media buyer Shan, Shan'S Digital8 is an elite growth agency dedicated to converting digital attention into measurable revenue. 
                With over $4.8M+ in managed advertising spend and an average 5.8x blended ROAS across 120+ client brands, we merge algorithmic auction mastery with high-converting creative psychology.
              </p>
              <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 leading-relaxed">
                We empower both local Pakistani enterprises scaling Cash-on-Delivery (COD) stores and global DTC brands in the United States, United Kingdom, and the UAE.
              </p>
              <div className="pt-2 flex items-center gap-4">
                <button
                  onClick={() => onNavigate('agency')}
                  className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 hover:text-orange-500 transition-colors"
                >
                  <span>Read Shan's Complete Story</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 grid grid-cols-2 gap-4">
              <div className="p-6 rounded-2xl bg-white dark:bg-[#141414] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
                <span className="text-2xl sm:text-3xl font-black text-orange-600">$4.8M+</span>
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 block">Ad Spend Managed</span>
                <p className="text-[11px] text-neutral-400">Strictly tracked across Meta Ads Manager & TikTok Center.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white dark:bg-[#141414] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
                <span className="text-2xl sm:text-3xl font-black text-amber-500">5.8x</span>
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 block">Average ROAS</span>
                <p className="text-[11px] text-neutral-400">Blended cash return on advertising investment.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white dark:bg-[#141414] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
                <span className="text-2xl sm:text-3xl font-black text-emerald-500">89%+</span>
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 block">COD Delivery Rate</span>
                <p className="text-[11px] text-neutral-400">Via automated WhatsApp confirmation bots in Pakistan.</p>
              </div>
              <div className="p-6 rounded-2xl bg-white dark:bg-[#141414] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
                <span className="text-2xl sm:text-3xl font-black text-blue-500">120+</span>
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 block">Brands Scaled</span>
                <p className="text-[11px] text-neutral-400">Across Pakistan, USA, UK, UAE, and Europe.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Our Main Services Section */}
      <section className="py-20 md:py-28 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-neutral-200 dark:border-neutral-800">
            <div className="space-y-2 max-w-2xl">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                Core Specializations
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
                Our Main Services
              </h2>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Dedicated growth departments engineered to work together as a unified customer acquisition system.
              </p>
            </div>

            <button
              onClick={() => onNavigate('services')}
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 hover:text-orange-500 transition-colors"
            >
              <span>View All Services</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mainServices.map((svc) => (
              <div
                key={svc.id}
                onClick={() => onNavigate(svc.id)}
                className={`group p-6 sm:p-8 rounded-3xl border transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-6 ${
                  svc.flagship
                    ? 'bg-gradient-to-br from-orange-950/20 via-white dark:via-[#141414] to-amber-950/20 border-orange-500/60 shadow-xl shadow-orange-950/10'
                    : 'bg-white dark:bg-[#121212] border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 shadow-sm'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="p-3 rounded-2xl bg-neutral-100 dark:bg-neutral-800/80 w-fit">
                      {svc.icon}
                    </div>
                    {svc.flagship && (
                      <span className="text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full bg-orange-600 text-white shadow-md">
                        Flagship
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
                      {svc.tagline}
                    </span>
                    <h3 className="text-xl font-bold text-neutral-900 dark:text-white group-hover:text-orange-500 transition-colors mt-0.5">
                      {svc.title}
                    </h3>
                  </div>

                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                    {svc.desc}
                  </p>

                  <div className="space-y-1.5 pt-2 border-t border-neutral-100 dark:border-neutral-800/80">
                    {svc.highlights.map((h, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-neutral-700 dark:text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-bold text-orange-600 dark:text-orange-400">
                  <span>Explore Channel Strategy</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Latest Client Results Section */}
      <ResultsGallery
        onSelectCaseStudy={onSelectCaseStudy}
        onOpenAudit={onOpenAudit}
      />

      {/* 5. Featured Meta Ads Service Callout */}
      <section className="py-16 bg-neutral-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="p-8 sm:p-12 rounded-3xl bg-neutral-950 border border-neutral-800 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-3 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 text-xs font-bold uppercase tracking-wider border border-orange-500/30">
                <Award className="w-4 h-4" />
                <span>Our Flagship Offering</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black tracking-tight">
                Complete Meta Ads Management
              </h2>
              <p className="text-sm text-neutral-300 leading-relaxed">
                "Turn Your Advertising Into Real Business Opportunities." We handle complete Campaign Management, Audience Strategy, High-Converting Creatives, and Server-Side CAPI tracking.
              </p>
              <div className="flex flex-wrap gap-4 text-xs text-neutral-400 pt-1">
                <span>✓ Facebook & Instagram Ads</span>
                <span>✓ WhatsApp Click-to-Chat</span>
                <span>✓ Advantage+ Shopping (ASC+)</span>
                <span>✓ CAPI 95%+ Match Quality</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              <button
                onClick={() => onNavigate('meta-ads')}
                className="px-6 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
              >
                Inspect Meta Ads Architecture
              </button>
              <button
                onClick={onOpenTrial}
                className="px-6 py-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider border border-neutral-700 transition-colors"
              >
                Apply for 7-Day Free Trial
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Free Offers Section */}
      <section className="py-20 md:py-28 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Risk-Free Opportunities
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
              Agency Promotional Offers
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Experience Shan'S Digital8 performance marketing before committing to any long-term arrangement.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Offer 1: 7-Day Free Trial */}
            <div className="p-8 rounded-3xl bg-gradient-to-br from-orange-950/20 via-white dark:via-[#141414] to-amber-950/20 border-2 border-orange-500/60 shadow-lg flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-orange-500/20 text-orange-600 dark:text-orange-400 text-[10px] font-bold uppercase tracking-wider">
                  <Gift className="w-3 h-3" />
                  <span>Flagship Promotion</span>
                </div>
                <h3 className="text-xl font-black text-neutral-900 dark:text-white">
                  7 DAYS FREE META ADS MANAGEMENT TRIAL
                </h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Experience professional advertising management for seven days without paying a management fee. You pay your ad budget directly to Meta.
                </p>
              </div>
              <button
                onClick={onOpenTrial}
                className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-md text-center"
              >
                CLAIM 7-DAY FREE TRIAL
              </button>
            </div>

            {/* Offer 2: 100% Free Ads Audit */}
            <div className="p-8 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-bold uppercase tracking-wider">
                  <FileSearch className="w-3 h-3" />
                  <span>Account Diagnostics</span>
                </div>
                <h3 className="text-xl font-black text-neutral-900 dark:text-white">
                  100% FREE META ADS ACCOUNT AUDIT
                </h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  Deep review of your campaign structure, audience targeting, CAPI tracking, creative fatigue, and ROAS improvement opportunities.
                </p>
              </div>
              <button
                onClick={onOpenAudit}
                className="w-full py-3 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-bold text-xs uppercase tracking-wider hover:bg-orange-600 dark:hover:bg-orange-500 dark:hover:text-white transition-colors text-center"
              >
                GET MY FREE ADS AUDIT
              </button>
            </div>

            {/* Offer 3: Free Strategy Consultation */}
            <div className="p-8 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
                  <MessageCircle className="w-3 h-3" />
                  <span>1-on-1 Consultation</span>
                </div>
                <h3 className="text-xl font-black text-neutral-900 dark:text-white">
                  FREE MARKETING STRATEGY CONSULTATION
                </h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  20-minute strategy session with Shan to review your unit economics, COD courier return rates, and multi-channel expansion.
                </p>
              </div>
              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20would%20like%20to%20claim%20the%20Free%20Marketing%20Strategy%20Consultation."
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-md text-center block"
              >
                Schedule via WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Why Choose Shan'S Digital8 */}
      <section className="py-20 bg-neutral-50 dark:bg-[#0d0d0d] border-y border-neutral-200 dark:border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              The Agency Advantage
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
              Why Choose Shan'S Digital8
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChooseUs.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 space-y-2.5 shadow-sm"
              >
                <div className="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-500 flex items-center justify-center font-black text-sm">
                  0{idx + 1}
                </div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Industries We Serve */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Sector Specialization
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
              Industries We Serve
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Tailored campaign strategies built around the buying cycles of each specific industry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.map((ind, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all flex items-start gap-4 shadow-sm"
              >
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 shrink-0">
                  {ind.icon}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-white">{ind.name}</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 leading-relaxed">{ind.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. Our Working Process */}
      <ProcessSection />

      {/* 10. Featured Case Studies Showcase */}
      <section className="py-20 bg-neutral-50 dark:bg-[#0d0d0d] border-y border-neutral-200 dark:border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
                Detailed Case Studies
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
                Battle-Tested Brand Blueprints
              </h2>
            </div>
            <button
              onClick={() => onNavigate('results')}
              className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 hover:text-orange-500"
            >
              <span>Explore All Case Studies</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CASE_STUDIES.slice(0, 2).map((study) => (
              <div
                key={study.id}
                onClick={() => onSelectCaseStudy(study)}
                className="group p-6 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/50 shadow-sm transition-all cursor-pointer space-y-4"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-orange-500 uppercase tracking-wider">
                    {study.platform}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                    Verified
                  </span>
                </div>
                <h3 className="text-lg font-bold text-neutral-900 dark:text-white group-hover:text-orange-500 transition-colors">
                  {study.title}
                </h3>
                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-900 text-xs">
                  <div>
                    <span className="text-[10px] text-neutral-400 block font-bold">SPEND</span>
                    <span className="font-bold text-neutral-800 dark:text-neutral-200">{study.results.spend}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block font-bold">REVENUE</span>
                    <span className="font-black text-emerald-500">{study.results.revenue}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block font-bold">ROAS</span>
                    <span className="font-black text-orange-500">{study.results.roas}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs font-bold text-orange-500 pt-1">
                  <span>View Full Case Breakdown</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 11. Client Testimonials */}
      <Testimonials />

      {/* 12. Frequently Asked Questions (FAQs) */}
      <section className="py-20 md:py-28">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
              Clear Answers
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-neutral-900 dark:text-white">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-[#121212] overflow-hidden transition-all shadow-sm"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm text-neutral-900 dark:text-white"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-orange-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed border-t border-neutral-100 dark:border-neutral-800">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 13. High-Converting Contact CTA */}
      <section className="py-20 bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 text-white border-t border-neutral-800 relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8 relative z-10">
          <div className="space-y-4 max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-widest text-orange-500">
              Take Action Today
            </span>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              Ready To Scale Your Digital Advertising With Real Return On Ad Spend?
            </h2>
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Claim your 7-Day Free Meta Ads Management Trial, get a 100% Free Account Audit, or chat directly with Shan on WhatsApp right now.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={onOpenTrial}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40 transform hover:-translate-y-0.5 active:scale-95"
            >
              CLAIM YOUR 7-DAY FREE TRIAL
            </button>

            <button
              onClick={onOpenAudit}
              className="w-full sm:w-auto px-6 py-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs uppercase tracking-wider border border-neutral-700 transition-all active:scale-95"
            >
              GET FREE ADS AUDIT
            </button>

            <a
              href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20am%20ready%20to%20scale%20my%20business."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-6 py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Shan</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

import { PageRoute } from '../types';
import {
  Video,
  Sparkles,
  Zap,
  TrendingUp,
  Target,
  ShoppingBag,
  Cpu,
  CheckCircle2,
  ArrowRight,
  Flame,
  MessageCircle,
  Eye
} from 'lucide-react';

interface TikTokAdsPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function TikTokAdsPage({ onOpenAudit, onNavigate }: TikTokAdsPageProps) {
  const pillars = [
    {
      icon: <Sparkles className="w-6 h-6 text-pink-500" />,
      title: 'Spark Ads & Creator Whitelisting',
      desc: 'Running dark ads directly through real influencer profiles and customer TikTok accounts. Delivers 3x higher authenticity and click-through rates than ordinary brand ads.',
    },
    {
      icon: <Flame className="w-6 h-6 text-orange-500" />,
      title: '3-Second Viral Hook Strategy',
      desc: 'The auction is won or lost in the first 3 seconds. We engineer curiosity gaps, shock factors, and problem demonstrations that stop fast-scrolling Gen Z and Millennials.',
    },
    {
      icon: <ShoppingBag className="w-6 h-6 text-amber-500" />,
      title: 'TikTok Shop Advertising',
      desc: 'Scaling in-feed video ads with 1-click in-app TikTok Shop checkout. Frictionless buying experience generating record-breaking impulse order volume.',
    },
    {
      icon: <Target className="w-6 h-6 text-blue-500" />,
      title: 'Algorithm & Audience Targeting',
      desc: 'Hashtag targeting, creator interaction clusters, broad algorithmic audience matching, and high-value Lookalikes generated from your customer lists.',
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-emerald-500" />,
      title: 'E-commerce & Lead Gen Scaling',
      desc: 'High-volume purchase campaigns for fashion, beauty, tech gadgets, and instant lead gen forms optimized for local services and appointments.',
    },
    {
      icon: <Cpu className="w-6 h-6 text-purple-500" />,
      title: 'TikTok Pixel 2.0 & Events API',
      desc: 'Full-funnel server-to-server tracking matching email, phone, and IP hashes to supercharge TikTok’s bidding engine for lower cost per purchase.',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <button onClick={() => onNavigate('services')} className="hover:text-orange-500 transition-colors">
            Services
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">TikTok Ads Management</span>
        </div>

        {/* Hero Banner */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-[#121212] to-neutral-950 border border-neutral-800 p-8 sm:p-12 lg:p-16 text-white shadow-2xl">
          <div className="max-w-3xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs font-bold uppercase tracking-wider">
              <Flame className="w-4 h-4 text-orange-500" />
              <span>High-Velocity Scaling Channel</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.1] [text-wrap:balance]">
              Scale Beyond Facebook With Viral TikTok Ads & Spark Campaigns.
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed">
              Unlock unmatched reach and lower CPMs on the world's most engaging short-form video platform. 
              We turn native user-generated content into scalable sales machines for e-commerce, D2C brands, and local services in the US, UK, GCC, and Pakistan.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAudit}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-xl shadow-orange-950/40"
              >
                <span>Book TikTok Strategy Call</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20am%20interested%20in%20scaling%20my%20brand%20with%20TikTok%20Ads."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>WhatsApp Shan</span>
              </a>
            </div>
          </div>
        </div>

        {/* Featured Case Metric Ribbon */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 text-white space-y-1">
            <span className="text-xs uppercase font-bold text-neutral-400">Verified Client Case</span>
            <div className="text-3xl font-black text-orange-500">5.9x ROAS</div>
            <p className="text-xs text-neutral-300">PulseAudio Earbuds (US & UK) scaled from $0 to $248K on TikTok Ads.</p>
          </div>
          <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 text-white space-y-1">
            <span className="text-xs uppercase font-bold text-neutral-400">Average CPM Advantage</span>
            <div className="text-3xl font-black text-amber-500">-38% Lower CPM</div>
            <p className="text-xs text-neutral-300">Cheaper audience acquisition compared to crowded legacy advertising channels.</p>
          </div>
          <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 text-white space-y-1">
            <span className="text-xs uppercase font-bold text-neutral-400">Impression Velocity</span>
            <div className="text-3xl font-black text-emerald-500">1.2M+ Reach</div>
            <p className="text-xs text-neutral-300">Achieved in single testing sprints through dynamic creator Spark Ads.</p>
          </div>
        </div>

        {/* Pillars Grid */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-black text-neutral-900 dark:text-white">
              The TikTok Performance Engine
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Unlike static image ads, TikTok requires continuous creative momentum and native video psychology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pillars.map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/40 transition-all shadow-sm space-y-3"
              >
                <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800/80 w-fit">
                  {item.icon}
                </div>
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Footer Card */}
        <div className="p-8 sm:p-12 rounded-3xl bg-neutral-900 border border-neutral-800 text-white flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <h3 className="text-2xl sm:text-3xl font-black">
              Want to see if your product is ready for TikTok Ads?
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Shan will analyze your product margins, video assets, and competitors on TikTok Creative Center at zero cost.
            </p>
          </div>
          <button
            onClick={onOpenAudit}
            className="px-8 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shrink-0"
          >
            Request Free TikTok Audit
          </button>
        </div>
      </div>
    </div>
  );
}

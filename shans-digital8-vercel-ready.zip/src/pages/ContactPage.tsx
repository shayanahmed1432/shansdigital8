import { useState } from 'react';
import { PageRoute } from '../types';
import {
  MessageCircle,
  Mail,
  Phone,
  Clock,
  MapPin,
  Send,
  CheckCircle2,
  Gift,
  FileSearch,
  Sparkles,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface ContactPageProps {
  onOpenAudit: () => void;
  onOpenTrial: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function ContactPage({ onOpenAudit, onOpenTrial, onNavigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    market: 'Pakistan (PKR)',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await fetch('/api/leads/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.fullName,
          phoneWhatsapp: formData.phone,
          brandWebsite: formData.email,
          monthlyAdSpend: formData.market,
          message: formData.message,
        }),
      });
      setIsSubmitted(true);
    } catch (err) {
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button onClick={() => onNavigate('home')} className="hover:text-orange-500 transition-colors">
            Home
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Contact & Client Inquiries</span>
        </div>

        {/* Page Hero Header */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-600 dark:text-orange-400 text-xs font-bold uppercase tracking-wider">
            <MessageCircle className="w-4 h-4" />
            <span>Fast Direct Communication</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-neutral-900 dark:text-white leading-[1.1] [text-wrap:balance]">
            Let’s Discuss Scaling Your Business.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            Have a question about our 7-Day Free Trial, Meta Ads Management, or local COD courier funnels in Pakistan? 
            Message Shan directly on WhatsApp or submit your inquiry below.
          </p>
        </div>

        {/* Quick Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: WhatsApp Direct */}
          <a
            href="https://wa.me/923332327001?text=Hi!%20I%20want%20to%20know%20more%20about%20your%20digital%20marketing%20services."
            target="_blank"
            rel="noreferrer"
            className="p-8 rounded-3xl bg-emerald-600 text-white shadow-xl hover:bg-emerald-500 transition-all flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
                <MessageCircle className="w-6 h-6 fill-white" />
              </div>
              <h3 className="text-xl font-black">WhatsApp 1-on-1</h3>
              <p className="text-xs text-emerald-100 leading-relaxed">
                Direct channel with Shan. Fastest response time (typically under 30 minutes during business hours).
              </p>
            </div>
            <div className="text-xs font-bold uppercase tracking-wider underline underline-offset-4 flex items-center gap-1">
              <span>Open WhatsApp Chat</span>
              <span>→</span>
            </div>
          </a>

          {/* Card 2: Free 7-Day Trial */}
          <div
            onClick={onOpenTrial}
            className="p-8 rounded-3xl bg-neutral-900 border border-neutral-800 text-white shadow-xl hover:border-orange-500/50 transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                <Gift className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black">7-Day Free Trial</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Experience full Meta Ads campaign management without paying an agency management fee for 7 days.
              </p>
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-orange-400 group-hover:text-orange-300 flex items-center gap-1">
              <span>Apply for Trial Slot</span>
              <span>→</span>
            </div>
          </div>

          {/* Card 3: Free Ads Audit */}
          <div
            onClick={onOpenAudit}
            className="p-8 rounded-3xl bg-neutral-900 border border-neutral-800 text-white shadow-xl hover:border-amber-500/50 transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <FileSearch className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black">Free Ads Audit</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Already running ads? Let Shan evaluate your ad spend, CAPI tracking, creative fatigue, and ROAS leaks.
              </p>
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 group-hover:text-amber-300 flex items-center gap-1">
              <span>Request Free Audit</span>
              <span>→</span>
            </div>
          </div>
        </div>

        {/* Contact Form & Agency Details */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Form */}
          <div className="lg:col-span-7 p-8 rounded-3xl bg-white dark:bg-[#121212] border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <h3 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
              Send An Inquiry
            </h3>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 mb-6">
              Fill out this quick form and Shan will respond within 24 hours.
            </p>

            {isSubmitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-neutral-900 dark:text-white">
                  Message Sent Successfully!
                </h4>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 max-w-sm mx-auto">
                  Thank you, {formData.fullName}. Shan has received your inquiry and will contact you via WhatsApp or email promptly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Bilal Tariq"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      WhatsApp / Phone *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+92 300 0000000"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="you@yourbrand.com"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    Target Market & Currency
                  </label>
                  <select
                    value={formData.market}
                    onChange={(e) => setFormData({ ...formData, market: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  >
                    <option value="Pakistan (PKR)">Pakistan (PKR) - Local D2C / COD</option>
                    <option value="United States (USD)">United States (USD) - DTC E-commerce</option>
                    <option value="United Kingdom (GBP)">United Kingdom (GBP)</option>
                    <option value="United Arab Emirates (AED)">United Arab Emirates (AED / GCC)</option>
                    <option value="Europe (EUR)">Europe (EUR)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    How can Shan help your business?
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about your product, current ad spend, or specific challenges (e.g., low ROAS, COD returns, scaling)..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white text-xs focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Inquiry</span>
                </button>
              </form>
            )}
          </div>

          {/* Right Agency Information */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-8 rounded-3xl bg-neutral-900 border border-neutral-800 text-white space-y-6">
              <h3 className="text-xl font-bold">Agency Headquarters & Coverage</h3>

              <div className="space-y-4 text-xs text-neutral-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-white">Local Pakistani Presence:</strong>
                    <span>Serving clients across Karachi, Lahore, Islamabad, Rawalpindi, and Faisalabad. Deep COD courier integration.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-white">International Client Accounts:</strong>
                    <span>United States (EST/PST), United Kingdom (GMT), and UAE/GCC (GST). Multi-currency ad account experience.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-white">Working Hours & Response Time:</strong>
                    <span>Monday to Saturday, 9:00 AM – 9:00 PM PKT. Urgent client ad account alerts monitored 24/7.</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-800">
                <a
                  href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I%20want%20to%20connect."
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>Direct WhatsApp Line: +92 300 0000000</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { PageRoute } from '../types';
import { ArrowLeft, Calculator, ArrowRight, DollarSign, TrendingUp, Sparkles, MessageCircle, CheckCircle2, Globe2 } from 'lucide-react';
import { SUPPORTED_MARKETS, MarketConfig, formatCurrencyAmount } from '../data/marketData';

interface CalculatorPageProps {
  onOpenAuditWithSpend: (spend: number) => void;
  onNavigate: (page: PageRoute) => void;
}

export default function CalculatorPage({ onOpenAuditWithSpend, onNavigate }: CalculatorPageProps) {
  const [selectedMarket, setSelectedMarket] = useState<MarketConfig>(SUPPORTED_MARKETS[0]); // Default Pakistan
  const [adSpend, setAdSpend] = useState<number>(selectedMarket.defaultSpend);
  const [targetRoas, setTargetRoas] = useState<number>(selectedMarket.defaultRoas);
  const [aov, setAov] = useState<number>(selectedMarket.defaultAov);

  const handleMarketChange = (market: MarketConfig) => {
    setSelectedMarket(market);
    setAdSpend(market.defaultSpend);
    setTargetRoas(market.defaultRoas);
    setAov(market.defaultAov);
  };

  const projectedRevenue = Math.round(adSpend * targetRoas);
  const netAdProfit = Math.round(projectedRevenue - adSpend);
  const estimatedOrders = Math.round(projectedRevenue / (aov || 1));

  const recommendation = selectedMarket.getRecommendation(adSpend);

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-orange-500 flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Multi-Country ROAS Growth Calculator</span>
        </div>

        {/* Page Header */}
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            <Globe2 className="w-4 h-4" />
            <span>Multi-Market Financial Modeling · Pakistan 🇵🇰 & International 🌍</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-950 dark:text-white leading-[1.1] [text-wrap:balance]">
            Calculate Your Ad Returns & Net Profit Margins.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            From local Pakistani Cash-on-Delivery (COD) stores in PKR to international e-commerce scaling in the USA, UK, UAE, and Europe — benchmark your return on ad spend (ROAS) using Shan'S Digital8 algorithmic media buying models.
          </p>
        </div>

        {/* Country / Market Selection Bar */}
        <div className="p-6 rounded-2xl bg-neutral-50 dark:bg-neutral-900/80 border border-neutral-200 dark:border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Select Market & Currency:
            </span>
            <span className="text-xs text-orange-600 dark:text-orange-400 font-medium font-mono">
              Active: {selectedMarket.currencyCode}
            </span>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {SUPPORTED_MARKETS.map((m) => {
              const isSelected = selectedMarket.id === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => handleMarketChange(m)}
                  className={`inline-flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition-all duration-200 active:scale-95 ${
                    isSelected
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white shadow-md'
                      : 'bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-orange-500'
                  }`}
                >
                  <span className="text-lg">{m.flag}</span>
                  <span>{m.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Column */}
          <div className="lg:col-span-6 p-6 sm:p-8 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-8">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="calc-ad-spend" className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Monthly Advertising Budget ({selectedMarket.currencyCode})
                </label>
                <span className="text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                  {formatCurrencyAmount(adSpend, selectedMarket)}
                </span>
              </div>
              <input
                id="calc-ad-spend"
                type="range"
                min={selectedMarket.minSpend}
                max={selectedMarket.maxSpend}
                step={selectedMarket.stepSpend}
                value={adSpend}
                onChange={(e) => setAdSpend(Number(e.target.value))}
                className="w-full h-3 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
              <div className="flex justify-between text-xs text-neutral-400 font-mono">
                <span>{selectedMarket.spendLabels.low} (Low/Entry)</span>
                <span>{selectedMarket.spendLabels.mid}</span>
                <span>{selectedMarket.spendLabels.high} (Scale)</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="calc-target-roas" className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Target ROAS Multiple
                </label>
                <span className="text-2xl font-bold font-mono text-orange-600 dark:text-orange-400 tabular-nums">
                  {targetRoas.toFixed(1)}x
                </span>
              </div>
              <input
                id="calc-target-roas"
                type="range"
                min="2.0"
                max="8.0"
                step="0.1"
                value={targetRoas}
                onChange={(e) => setTargetRoas(Number(e.target.value))}
                className="w-full h-3 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
              <div className="flex justify-between text-xs text-neutral-400 font-mono">
                <span>2.0x (Break-even)</span>
                <span>5.0x (Shan'S Average)</span>
                <span>8.0x (Top Performers)</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold text-neutral-900 dark:text-white">
                  Average Order Value (AOV)
                </label>
                <span className="text-base font-bold font-mono text-neutral-900 dark:text-white tabular-nums">
                  {formatCurrencyAmount(aov, selectedMarket)}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {selectedMarket.aovOptions.map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAov(val)}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold font-mono border transition-all ${
                      aov === val
                        ? 'bg-orange-600 text-white border-orange-600 shadow-sm'
                        : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-orange-500'
                    }`}
                  >
                    {formatCurrencyAmount(val, selectedMarket)}
                  </button>
                ))}
              </div>
            </div>

            {/* Presets */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 space-y-2">
              <div className="text-xs font-medium text-neutral-500">
                Preset Scenarios for {selectedMarket.shortName}:
              </div>
              <div className="flex flex-wrap gap-2">
                {selectedMarket.presets.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setAdSpend(p.spend);
                      setTargetRoas(p.roas);
                      setAov(p.aov);
                    }}
                    className="px-2.5 py-1.5 text-xs rounded-md bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 sm:p-8 rounded-2xl bg-neutral-900 text-white border border-neutral-800 shadow-2xl space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-orange-500" />
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    {selectedMarket.name} Growth Projection
                  </span>
                </div>
                <span className="text-xs font-mono text-emerald-400 font-semibold uppercase">
                  Verified Formula
                </span>
              </div>

              <div className="space-y-1">
                <div className="text-xs text-neutral-400">Projected Gross Monthly Revenue</div>
                <div className="text-4xl sm:text-5xl font-extrabold font-mono text-white tabular-nums tracking-tight">
                  <span className="text-orange-500">{selectedMarket.currencySymbol} </span>
                  {projectedRevenue.toLocaleString()}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <div className="text-xs text-neutral-400">Net Return Margin</div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                    +{formatCurrencyAmount(netAdProfit, selectedMarket)}
                  </div>
                  <div className="text-[11px] text-neutral-400">Gross Sales minus Ad Spend</div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <div className="text-xs text-neutral-400">Estimated Orders</div>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">
                    {estimatedOrders.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-neutral-400">At {formatCurrencyAmount(aov, selectedMarket)} AOV</div>
                </div>
              </div>

              {/* Strategy Card */}
              <div className="p-5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-orange-400 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Shan's Recommended Campaign Framework</span>
                </div>
                <div className="text-sm font-semibold text-white">
                  {recommendation.strategy}
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {recommendation.focus}
                </p>
                <div className="p-2.5 rounded-lg bg-orange-950/40 border border-orange-900/40 text-[11px] text-orange-300">
                  <strong className="text-white">Local Insight:</strong> {recommendation.marketInsight}
                </div>
                <div className="text-[11px] text-neutral-400 pt-1 font-mono">
                  Recommended Creative Velocity: {recommendation.creativeVelocity}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => onOpenAuditWithSpend(adSpend)}
                  className="flex-1 py-4 px-4 rounded-xl bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-600 text-white text-xs sm:text-sm font-bold uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>Build This Plan with Shan</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={`https://wa.me/923000000000?text=${encodeURIComponent(
                    `Hi Shan! I calculated my ad projections for ${selectedMarket.name}:\n• Monthly Budget: ${formatCurrencyAmount(adSpend, selectedMarket)}\n• Target ROAS: ${targetRoas.toFixed(1)}x\n• Projected Sales: ${formatCurrencyAmount(projectedRevenue, selectedMarket)}\n• Market: ${selectedMarket.name}\nCan you help execute this media plan for my store?`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-4 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/30 transition-all active:scale-95 whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp This Plan</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Local vs International Scaling Guide */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8">
          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
              <span>🇵🇰 Pakistan Local E-Commerce Playbook</span>
            </div>
            <h3 className="text-xl font-bold text-neutral-900 dark:text-white">
              Conquering Cash-on-Delivery (COD) & Courier Returns
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
              In Pakistan, high order volume means nothing if return-to-origin (RTO) rates hit 30%+. We pair high-converting Urdu/Roman Urdu Meta Advantage+ campaigns with automated WhatsApp 1-click confirmation bots and courier webhooks (PostEx, Trax, Leopards) to push delivered orders to 88%–90%.
            </p>
            <ul className="space-y-2 text-xs text-neutral-700 dark:text-neutral-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Instant automated WhatsApp address & phone verification</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Targeted delivery in high-purchasing cities across Pakistan</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Urdu & English UGC unboxings building high local brand trust</span>
              </li>
            </ul>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-orange-600 dark:text-orange-400 uppercase tracking-wider">
              <span>🌍 International E-Commerce Playbook (US, UK, UAE)</span>
            </div>
            <h3 className="text-xl font-bold text-neutral-900 dark:text-white">
              Advantage+ Shopping & TikTok Viral Scaling
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
              For brands targeting the United States, United Kingdom, and the Gulf, auction competitiveness requires superior creative hold rates and server-side tracking. We deploy full CAPI pipelines, Spark Ads creator whitelisting, and bid caps that scale past $50k/mo while protecting margins.
            </p>
            <ul className="space-y-2 text-xs text-neutral-700 dark:text-neutral-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Meta CAPI 95%+ event match quality bypassing iOS 14.5+ dropoffs</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>High-converting TikTok UGC Spark Ads & creator whitelisting</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Automated CBO budget scaling with Cost Cap and Minimum ROAS rules</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

import { SERVICES } from '../data/portfolioData';
import { PageRoute } from '../types';
import { ArrowLeft, Check, Layers, Zap, Video, BarChart3, ArrowRight, MessageCircle, ShieldCheck, Cpu } from 'lucide-react';

interface ServicesPageProps {
  onOpenAudit: () => void;
  onNavigate: (page: PageRoute) => void;
}

export default function ServicesPage({ onOpenAudit, onNavigate }: ServicesPageProps) {
  const getIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <Layers className="w-6 h-6 text-orange-500" />;
      case 1:
        return <Zap className="w-6 h-6 text-amber-500" />;
      case 2:
        return <Video className="w-6 h-6 text-orange-500" />;
      default:
        return <BarChart3 className="w-6 h-6 text-amber-500" />;
    }
  };

  const technicalStack = [
    {
      title: 'Server-Side Meta Conversions API (CAPI)',
      desc: 'Bypasses browser ad blockers, Safari ITP, and iOS 14.5 restrictions by piping server purchase events directly to Meta servers with 98% Event Match Quality.',
    },
    {
      title: 'TikTok Advanced Matching & Pixel 2.0',
      desc: 'High-fidelity event attribution matching email, phone, and IP hashes to supercharge TikTok FYP recommendation engine for low-CPA purchases.',
    },
    {
      title: 'Dynamic Creative Testing (DCT) Sandboxes',
      desc: '3:2:2 modular testing architecture (3 video hooks, 2 bodies, 2 CTAs) isolating winners before budget deployment into Advantage+ Shopping.',
    },
    {
      title: 'Cost Cap & Minimum ROAS Guardrails',
      desc: 'Mathematical bid caps programmed to throttle ad spend automatically if the auction fluctuates, protecting client gross profit margins.',
    },
  ];

  return (
    <div className="py-12 md:py-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-orange-500 flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
          <span>/</span>
          <span className="text-neutral-900 dark:text-white font-semibold">Media Buying Services</span>
        </div>

        {/* Page Header */}
        <div className="max-w-3xl space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            Performance Media Buying & Acquisition Engineering
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-950 dark:text-white leading-[1.1] [text-wrap:balance]">
            End-to-End Ads Management That Converts Cold Traffic.
          </h1>
          <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
            We operate as your dedicated growth partner. From technical tracking infrastructure and high-retention
            UGC creative production to automated CBO budget jumps, here is our full media buying capabilities suite.
          </p>
        </div>

        {/* 4 Core Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service, idx) => (
            <div
              key={service.number}
              className="p-8 sm:p-10 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm hover:border-orange-500/50 hover:shadow-xl transition-all duration-300 flex flex-col justify-between space-y-8"
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-base font-mono font-bold text-orange-600 dark:text-orange-400">
                      {service.number}.
                    </span>
                    <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700">
                      {getIcon(idx)}
                    </div>
                  </div>

                  <div className="text-xs text-neutral-500 font-medium">
                    {service.platforms.join(' · ')}
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl font-bold text-neutral-900 dark:text-white">
                    {service.title}
                  </h2>
                  <div className="text-xs font-semibold text-orange-600 dark:text-orange-400 mt-1">
                    {service.tagline}
                  </div>
                </div>

                <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {service.description}
                </p>

                <div className="space-y-3 pt-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                    What We Deliver:
                  </div>
                  {service.features.map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-3 text-xs text-neutral-700 dark:text-neutral-300">
                      <Check className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <button
                  onClick={onOpenAudit}
                  className="w-full py-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <span>Inquire for {service.title.split(' ')[0]} Ads</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Technical Tracking & Tracking Infrastructure Section */}
        <div className="p-8 sm:p-10 rounded-2xl bg-neutral-950 text-white border border-neutral-800 space-y-8">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-400">
              <Cpu className="w-4 h-4" />
              <span>Technical Infrastructure</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              The Data Tracking Architecture Behind 6x ROAS
            </h2>
            <p className="text-sm text-neutral-400 max-w-2xl">
              Without accurate data attribution, ad algorithms fly blind. We configure enterprise-grade server tracking so Meta and TikTok algorithms get pristine purchase signals.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {technicalStack.map((tech, idx) => (
              <div
                key={idx}
                className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2"
              >
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{tech.title}</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {tech.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* 30-Day Onboarding Roadmap */}
        <div className="p-8 sm:p-10 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-8">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-neutral-900 dark:text-white">
              First 30 Days Partnership Roadmap
            </h2>
            <p className="text-xs text-neutral-500">
              What to expect from day 1 of hiring Shan'S Digital8 as your media buying team.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div className="space-y-2 border-t-2 border-orange-500 pt-4">
              <div className="text-xs font-mono font-bold text-orange-500">WEEK 01</div>
              <div className="text-sm font-bold text-neutral-900 dark:text-white">Forensic Audit & CAPI</div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Ad account access, event deduplication, pixel verification, and historical data autopsy.
              </p>
            </div>
            <div className="space-y-2 border-t-2 border-amber-500 pt-4">
              <div className="text-xs font-mono font-bold text-amber-500">WEEK 02</div>
              <div className="text-sm font-bold text-neutral-900 dark:text-white">Creative Testing Launch</div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Deploying 8-12 UGC hooks, scripts, and static carousels into DCT sandboxes to isolate winners.
              </p>
            </div>
            <div className="space-y-2 border-t-2 border-orange-500 pt-4">
              <div className="text-xs font-mono font-bold text-orange-500">WEEK 03</div>
              <div className="text-sm font-bold text-neutral-900 dark:text-white">Algorithmic Scaling</div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Winning ads graduate to Advantage+ Shopping & broad CBO with 20% budget bumps every 48 hours.
              </p>
            </div>
            <div className="space-y-2 border-t-2 border-amber-500 pt-4">
              <div className="text-xs font-mono font-bold text-amber-500">WEEK 04</div>
              <div className="text-sm font-bold text-neutral-900 dark:text-white">Omnichannel Retention</div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                Catalog retargeting, VIP lookalikes, TikTok Spark whitelisting, and scaling to multi-five-figure monthly revenue.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Callout */}
        <div className="p-8 sm:p-10 rounded-2xl bg-gradient-to-r from-orange-600 to-orange-500 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Ready to Turn Clicks Into Repeat Customers?
            </h3>
            <p className="text-sm text-orange-100 max-w-xl">
              Schedule your free 15-minute diagnostic call with Shan. We evaluate your current CPA and show you exactly where to scale.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <button
              onClick={onOpenAudit}
              className="w-full sm:w-auto px-7 py-3.5 text-xs font-bold uppercase tracking-wider text-neutral-950 bg-white hover:bg-neutral-100 rounded-xl shadow-lg transition-all active:scale-95 whitespace-nowrap min-h-[44px]"
            >
              Book Strategy Session
            </button>
            <a
              href="https://wa.me/923000000000?text=Assalam-o-Alaikum%20Shan!%20I'm%20interested%20in%20your%20ads%20management%20services."
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-6 py-3.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-600 rounded-xl shadow-lg transition-all active:scale-95 whitespace-nowrap flex items-center justify-center gap-2 min-h-[44px]"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp Shan</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

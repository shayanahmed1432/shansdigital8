export type AdPlatform = 'meta' | 'tiktok' | 'both';

export type CategoryFilter = 'all' | 'meta' | 'tiktok' | 'leadgen' | 'ecommerce' | 'local';

export type PageRoute =
  | 'home'
  | 'results'
  | 'services'
  | 'calculator'
  | 'creative-lab'
  | 'agency'
  | 'meta-ads'
  | 'social-media'
  | 'tiktok-ads'
  | 'creative-services'
  | 'ecommerce-management'
  | 'offers'
  | 'contact';

export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  platform: 'Meta Ads' | 'TikTok Ads' | 'Omnichannel';
  category: 'ecommerce' | 'leadgen';
  heroMetric: string;
  heroMetricLabel: string;
  image: string;
  results: {
    spend: string;
    revenue: string;
    roas: string;
    cpa: string;
    impressions?: string;
    leads?: string;
  };
  challenge: string;
  solution: string;
  keyTactics: string[];
  timeline: string;
  verifiedBadge: boolean;
}

export interface ClientResult {
  id: string;
  clientName: string;
  category: 'meta' | 'tiktok' | 'leadgen' | 'ecommerce' | 'local';
  platform: 'Meta Ads' | 'TikTok Ads' | 'Both';
  country: string;
  currency: string;
  spend: string;
  revenue: string;
  roas: string;
  leads?: string;
  purchases?: string;
  cpl?: string;
  cpa?: string;
  screenshotUrl?: string;
  verified: boolean;
  isProjection: boolean;
  isFeaturedHome: boolean;
  status: 'published' | 'draft';
  updatedAt: string;
  summary: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  role: string;
  company: string;
  companyType: string;
  quote: string;
  metricsResult: string;
  avatarSeed: string;
}

export interface AuditRequestData {
  fullName: string;
  email: string;
  phoneWhatsapp: string;
  brandWebsite: string;
  marketRegion?: string;
  primaryChannel: string;
  monthlyAdSpend: string;
  primaryChallenge: string;
  message?: string;
}

export interface TrialRequestData {
  fullName: string;
  businessName: string;
  whatsappNumber: string;
  businessCategory: string;
  socialLink: string;
  hasAdAccount: 'yes' | 'no';
  monthlyBudget: string;
  businessGoals: string;
}
